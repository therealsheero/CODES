require("dotenv").config({ path: __dirname + "/../.env" });

process.env.TZ="Asia/Kolkata";
const app = require("./app");
const PORT = 8000;

app.listen(PORT, () => {
  console.log(`[server] API listening on 127.0.0.1:${PORT}`);
});
