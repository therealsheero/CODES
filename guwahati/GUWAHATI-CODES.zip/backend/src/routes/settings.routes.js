const router = require("express").Router();

const settingsController =
require("../controllers/settings.controller");

router.get(
    "/",
    settingsController.getPublicSettings
);

router.get("/qr-settings", settingsController.getQRSettings);
router.get("/tokens-per-hour", settingsController.getTokensPerHourPublic);
router.get("/work-start-time", settingsController.getWorkStartTime);
router.get("/priority-settings", settingsController.getPrioritySettings);
router.get("/states", settingsController.getStates);
router.get("/districts-by-state", settingsController.getDistrictsByState);
router.get("/is-working-day", settingsController.isWorkingDay);
router.get("/today-notice", settingsController.getTodayNotice);
router.get("/service-types", settingsController.getServiceTypes);
router.get(
    "/service-form-settings/:id",
    settingsController.getServiceFormSettings
);

module.exports = router;
