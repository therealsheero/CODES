const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const cors = require("cors");

const bookingRoutes = require("./routes/booking.routes");
const availabilityRoutes = require("./routes/availability.routes");
const locationRoutes = require("./routes/location.routes");
const managerRoutes = require("./routes/manager.routes");
const heatmapRoutes =require("./routes/heatmap.routes");
const settingsRoutes =
require("./routes/settings.routes");
const app = express();
app.set("trust proxy", 1);

app.disable("x-powered-by");
app.use(
    helmet({
        frameguard:{
            action:"deny"
        }
    })
);
// app.use(cors({
//   origin: function(origin, callback) {
//     if (!origin) {
//       return callback(null, true);
//     }
// 
//     if (
//       origin === "https://generatetoken.page" ||
//       origin.endsWith(".generatetoken.page")
//     ) {
//       return callback(null, true);
//     }
// 
//     return callback(new Error("Not allowed by CORS"));
//   },
//   methods: ["GET", "POST", "PUT", "DELETE"],
//   credentials: true
// }));
app.use(express.json()); 
const apiLimiter = rateLimit({
    windowMs:15 * 60 * 1000,
    max:2000,
    message:{
        message:"Too many requests"
    }
});

app.use("/api", apiLimiter);
app.use("/api", heatmapRoutes);
app.use("/api/guard", require("./routes/guard.routes"));
app.use("/api/manager", managerRoutes);
app.use(
    "/api/settings",
    settingsRoutes
);
app.use("/api", locationRoutes);
app.get("/", (req, res) => {
  res.send("Appointment Token System API is running");
});
app.use("/api", bookingRoutes);
app.use("/api", availabilityRoutes);
app.use((err,req,res,next)=>{

console.error("[app] Unhandled backend error:", err.message);

res.status(500).json({
    message:"Internal server error"
});

});

module.exports = app;
