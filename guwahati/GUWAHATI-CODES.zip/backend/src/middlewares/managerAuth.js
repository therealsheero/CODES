// const { MANAGER_TOKEN } = require("../utils/manager.config");

function managerAuth(req, res, next) {
  const token = req.headers["x-manager-token"];

  if (token !== "MANAGER_SESSION") {
    return res.status(401).json({ message: "Unauthorized" });
  }

  next();
}

module.exports = managerAuth;
