const db = require("../models/db");
const { getISTDateString } = require("../utils/date.utils");

exports.getPublicSettings = async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT
        rule_key,
        rule_value
      FROM priority_rules
      WHERE rule_key IN (
        'appointment_days_visible',
        'walkin_start_hour',
        'walkin_end_hour',
        'today_appointment_cutoff_hour',
        'geo_start_1',
        'geo_end_1',
        'geo_start_2',
        'geo_end_2',
        'geofence_distance_meters',
        'office_open_saturday',
        'office_open_sunday',
        'default_tokens_per_hour',
        'office_display_en',
        'office_display_hi',
        'office_short_name',
        'watermark_text',
        'gazette_office_address'
      )
    `);

    res.json(rows);
  } catch (err) {
    console.error("[settings] getPublicSettings DB error:", err);

    return res.status(500).json({
      message: "DB error",
    });
  }
};

exports.getQRSettings = async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT *
      FROM qr_settings
    `);

    res.json(rows);
  } catch (err) {
    console.error("[settings] getQRSettings DB error:", err);

    return res.status(500).json({
      message: "DB error",
    });
  }
};

async function getDefaultTokensPerHour(date) {
  const day = new Date(date).getDay();

  const [rows] = await db.execute(
    `
    SELECT tokens_per_hour
    FROM weekday_slot_rules
    WHERE weekday = ?
    `,
    [day]
  );

  return rows[0]?.tokens_per_hour || 30;
}

exports.getTokensPerHourPublic = async (req, res) => {
  const { date } = req.query;

  if (!date) {
    return res.status(400).json({
      message: "Date required",
    });
  }

  try {
    const [rows] = await db.execute(
      `
      SELECT tokens_per_hour
      FROM daily_token_counters
      WHERE date = ?
      `,
      [date]
    );

    const defaultTokensPerHour = await getDefaultTokensPerHour(date);

    res.json({
      tokensPerHour:
        rows[0]?.tokens_per_hour ?? defaultTokensPerHour,
    });
  } catch (err) {
    console.error("[settings] getTokensPerHourPublic DB error:", err);

    return res.status(500).json({
      message: "DB error",
    });
  }
};

exports.getWorkStartTime = async (req, res) => {
  const { date } = req.query;

  const day = new Date(date).getDay();

  try {
    const [rows] = await db.execute(
      `
      SELECT work_start_time
      FROM weekday_slot_rules
      WHERE weekday = ?
      `,
      [day]
    );

    res.json({
      workStartTime: rows[0]?.work_start_time || "11:00",
    });
  } catch (err) {
    console.error("[settings] getWorkStartTime DB error:", err);

    return res.status(500).json({
      message: "DB error",
    });
  }
};

exports.getPrioritySettings = async (req, res) => {
  try {
    const [rules] = await db.execute(`
      SELECT *
      FROM priority_rules
    `);

    const [districts] = await db.execute(`
      SELECT state, district
      FROM priority_districts
      ORDER BY state, district
    `);

    res.json({
      rules,
      districts,
    });
  } catch (err) {
    console.error("[settings] getPrioritySettings DB error:", err);

    return res.status(500).json({
      message: "DB error",
    });
  }
};

exports.getStates = async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT DISTINCT state
      FROM districts
      WHERE active = 1
      ORDER BY state
    `);

    res.json(rows.map((r) => r.state));
  } catch (err) {
    console.error("[settings] getStates DB error:", err);

    return res.status(500).json({
      message: "DB error",
    });
  }
};

exports.getDistrictsByState = async (req, res) => {
  const { state } = req.query;

  try {
    const [rows] = await db.execute(
      `
      SELECT *
      FROM districts
      WHERE state = ?
      AND active = 1
      ORDER BY english_name
      `,
      [state]
    );

    res.json(rows);
  } catch (err) {
    console.error("[settings] getDistrictsByState DB error:", err);

    return res.status(500).json({
      message: "DB error",
    });
  }
};

exports.isWorkingDay = async (req, res) => {
  const { date } = req.query;
  const d = new Date(date);
  const day = d.getDay();

  try {
    const [holidayRows] = await db.execute(
      `
      SELECT reason
      FROM holidays
      WHERE date = ?
      `,
      [date]
    );

    if (holidayRows.length > 0) {
      return res.json({
        isWorkingDay: false,
      });
    }

    if (day !== 0 && day !== 6) {
      return res.json({
        isWorkingDay: true,
      });
    }

    const [workingRows] = await db.execute(
      `
      SELECT 1
      FROM working_days
      WHERE date = ?
      `,
      [date]
    );

    res.json({
      isWorkingDay: workingRows.length > 0,
    });
  } catch (err) {
    console.error("[settings] isWorkingDay DB error:", err);

    return res.status(500).json({
      message: "DB error",
    });
  }
};

exports.getTodayNotice = async (req, res) => {
  const today = getISTDateString();

  try {
    const [rows] = await db.execute(
      `
      SELECT message
      FROM notices
      WHERE date = ?
      `,
      [today]
    );

    res.json({
      message: rows[0]?.message || "",
    });
  } catch (err) {
    console.error("[settings] getTodayNotice DB error:", err);

    return res.status(500).json({
      message: "DB error",
    });
  }
};

exports.getServiceTypes = async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT *
      FROM service_types
      ORDER BY display_order
    `);

    res.json(rows);
  } catch (err) {
    console.error("[settings] getServiceTypes DB error:", err);

    return res.status(500).json({
      message: "DB error",
    });
  }
};

exports.getServiceFormSettings = async (req, res) => {
  const serviceId = req.params.id;

  try {
    const [rows] = await db.execute(
      `
      SELECT
        field_key,
        enabled,
        mandatory
      FROM service_form_settings
      WHERE service_type_id = ?
      ORDER BY field_key
      `,
      [serviceId]
    );

    res.json(rows);
  } catch (err) {
    console.error("[settings] getServiceFormSettings DB error:", err);

    return res.status(500).json({
      message: "DB error",
    });
  }
};