const { distanceMeters } = require("../utils/geofence");
const db = require("../models/db");

async function getPriorityRules() {

  const [rows] = await db.execute(
      `
      SELECT rule_key,
             rule_value
      FROM priority_rules
      `
  );

        const rules = {};

        rows.forEach(r => {

          rules[r.rule_key] =
            Number(r.rule_value);

        });

        return rules;

}
exports.checkLocation = async (req, res) => {
  const { latitude, longitude } = req.body;

  if (latitude == null || longitude == null) {
    return res.status(400).json({
      message: "Latitude and longitude required"
    });
  }

  const rules =
    await getPriorityRules();
const officeLat =
    rules.office_latitude || 26.871696;

const officeLon =
    rules.office_longitude || 80.999924;

const distance = distanceMeters(
    officeLat,
    officeLon,
    latitude,
    longitude
);

const allowedRadius =
    rules.geofence_distance_meters || 100;

  const distanceKm = Math.round((distance / 1000) * 100) / 100;
  return res.json({

    distance_meters:
        Math.round(distance),

    distance_km:
        distanceKm,

    allowed_radius:
        allowedRadius,

    inside:
        distance <= allowedRadius

});
};
