CREATE TABLE daily_slots (
    date DATE PRIMARY KEY,
    appointment_total INT,
    appointment_booked INT DEFAULT 0,
    walkin_total INT,
    walkin_booked INT DEFAULT 0,
    carry_forward_done TINYINT(1) DEFAULT 0
);

CREATE TABLE daily_token_counters (
    date DATE PRIMARY KEY,
    priority_count INT DEFAULT 0,
    normal_count INT DEFAULT 0,
    wp_count INT DEFAULT 0,
    wn_count INT DEFAULT 0,
    ap_count INT DEFAULT 0,
    an_count INT DEFAULT 0,
    last_token INT DEFAULT 0,
    wl_count INT DEFAULT 0,
    al_count INT DEFAULT 0,
    tokens_per_hour INT DEFAULT 40
);

CREATE TABLE otp_verifications (
    mobile VARCHAR(20) PRIMARY KEY,
    otp VARCHAR(20),
    expires_at BIGINT,
    attempts INT DEFAULT 0,
    verified TINYINT(1) DEFAULT 0
);

CREATE TABLE holidays (
    date DATE PRIMARY KEY,
    reason TEXT
);

CREATE TABLE priority_rules (
    rule_key VARCHAR(255) PRIMARY KEY,
    rule_value TEXT
);

CREATE TABLE priority_districts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    state VARCHAR(255),
    district VARCHAR(255),
    UNIQUE KEY uq_state_district (state, district)
);

CREATE TABLE notices (
    date DATE PRIMARY KEY,
    message TEXT
);

CREATE TABLE physical_reference_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    age INT,
    mobile VARCHAR(20),
    aadhaar_last4 VARCHAR(4),
    gender VARCHAR(50),
    state VARCHAR(255),
    district VARCHAR(255),
    service_type VARCHAR(255),
    token_type VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    token VARCHAR(100),
    reference_of VARCHAR(255),
    eid VARCHAR(100)
);

CREATE TABLE district_visit_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date DATE,
    district VARCHAR(255),
    mode VARCHAR(50),
    eid_type VARCHAR(50),
    visits INT
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(100) NOT NULL,
    session_name VARCHAR(255) NOT NULL,
    page VARCHAR(255) NOT NULL,
    recovery_code VARCHAR(255),
    is_active TINYINT(1) DEFAULT 1
);

CREATE TABLE working_days (
    date DATE PRIMARY KEY,
    reason TEXT
);

CREATE TABLE weekday_slot_rules (
    weekday INT PRIMARY KEY,
    weekday_name VARCHAR(50) NOT NULL,
    appointment_total INT NOT NULL,
    walkin_total INT NOT NULL,
    tokens_per_hour INT DEFAULT 30,
    work_start_time TIME
);

CREATE TABLE service_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    english_name VARCHAR(255) UNIQUE NOT NULL,
    hindi_name VARCHAR(255) NOT NULL,
    requires_eid TINYINT(1) DEFAULT 0,
    requires_sid TINYINT(1) DEFAULT 0,
    active TINYINT(1) DEFAULT 1,
    display_order INT DEFAULT 0,
    requires_identity TINYINT(1) DEFAULT 1
);

CREATE TABLE districts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    state VARCHAR(255),
    english_name VARCHAR(255) NOT NULL,
    hindi_name VARCHAR(255) NOT NULL,
    active TINYINT(1) DEFAULT 1,
    UNIQUE KEY uq_state_english (state, english_name)
);

CREATE TABLE geojson_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    state VARCHAR(255) UNIQUE,
    file_name VARCHAR(255) NOT NULL,
    file_path TEXT NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE qr_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    qr_type VARCHAR(255) UNIQUE NOT NULL,
    file_name VARCHAR(255),
    file_path TEXT,
    is_active TINYINT(1) DEFAULT 1,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE form_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    field_key VARCHAR(255) UNIQUE NOT NULL,
    field_label VARCHAR(255),
    enabled TINYINT(1) DEFAULT 1,
    mandatory TINYINT(1) DEFAULT 1,
    display_order INT DEFAULT 0
);

CREATE TABLE logo_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(255) UNIQUE,
    file_name VARCHAR(255),
    file_path TEXT,
    is_active TINYINT(1) DEFAULT 1,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    token VARCHAR(100),
    name VARCHAR(255),
    mobile VARCHAR(20),
    aadhaar_last4 VARCHAR(4),
    age INT,
    gender VARCHAR(50),
    divyang VARCHAR(50),
    district VARCHAR(255),
    service_type VARCHAR(255),
    qrc VARCHAR(255),
    date DATE,
    mode VARCHAR(50),
    priority VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    device_id VARCHAR(255),
    token_type VARCHAR(50),
    visited TINYINT(1) DEFAULT 0,
    visited_at DATETIME NULL,
    distance_meters INT,
    token_seq INT,
    entry_marked TINYINT(1) DEFAULT 0,
    entry_time DATETIME NULL,
    eid VARCHAR(100),
    identity_type VARCHAR(100),
    sid VARCHAR(100),
    hardware_fp VARCHAR(255),
    state VARCHAR(255),
    service_other TEXT
);

CREATE INDEX idx_tokens_date ON tokens(date);
CREATE INDEX idx_tokens_visited ON tokens(visited);
CREATE INDEX idx_tokens_service ON tokens(service_type);
CREATE INDEX idx_tokens_mode ON tokens(mode);

CREATE UNIQUE INDEX idx_token_seq_per_day
ON tokens(date, token_seq);

CREATE TABLE service_form_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_type_id INT NOT NULL,
    field_key VARCHAR(255) NOT NULL,
    enabled TINYINT(1) DEFAULT 1,
    mandatory TINYINT(1) DEFAULT 0,
    CONSTRAINT fk_service_form_service_type
        FOREIGN KEY (service_type_id)
        REFERENCES service_types(id)
);

CREATE TABLE dashboard_field_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dashboard VARCHAR(255) NOT NULL,
    field_key VARCHAR(255) NOT NULL,
    visible TINYINT(1) NOT NULL DEFAULT 1,
    display_order INT NOT NULL DEFAULT 0,
    UNIQUE KEY uq_dashboard_field (dashboard, field_key)
);