-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: generatetoken-mysql.mysql.database.azure.com    Database: kerala_token
-- ------------------------------------------------------
-- Server version	8.0.46-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `daily_slots`
--

DROP TABLE IF EXISTS `daily_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_slots` (
  `date` date NOT NULL,
  `appointment_total` int DEFAULT NULL,
  `appointment_booked` int DEFAULT '0',
  `walkin_total` int DEFAULT NULL,
  `walkin_booked` int DEFAULT '0',
  `carry_forward_done` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_slots`
--

LOCK TABLES `daily_slots` WRITE;
/*!40000 ALTER TABLE `daily_slots` DISABLE KEYS */;
INSERT INTO `daily_slots` VALUES ('2026-07-29',30,0,40,0,1),('2026-07-30',30,0,40,0,0),('2026-07-31',30,0,40,0,0),('2026-08-01',30,0,40,0,0),('2026-08-02',30,0,40,0,0),('2026-08-03',30,0,40,0,0),('2026-08-04',30,0,40,0,0),('2026-08-05',30,0,40,0,1),('2026-08-06',30,0,40,0,0),('2026-08-07',30,0,40,0,0),('2026-08-08',30,0,40,0,0),('2026-08-09',30,0,40,0,0),('2026-08-10',30,0,40,0,0),('2026-08-11',30,0,40,0,0),('2026-08-12',30,0,40,0,0),('2026-08-13',30,0,40,0,0),('2026-08-14',30,0,40,0,0),('2026-08-15',30,0,40,0,0),('2026-08-16',30,0,40,0,0),('2026-08-17',30,0,40,0,0),('2026-08-18',30,0,40,0,0),('2026-08-19',30,1,40,0,0),('2026-08-20',30,0,40,0,0),('2026-08-21',30,0,40,0,0),('2026-08-22',30,0,40,0,0),('2026-08-23',30,0,40,0,0),('2026-08-24',30,0,40,0,0),('2026-08-25',30,0,40,0,0),('2026-08-26',30,0,40,0,0),('2026-08-27',30,0,40,0,0),('2026-08-28',30,0,40,0,0),('2026-08-29',30,0,40,0,0),('2026-08-30',30,0,40,0,0),('2026-08-31',30,0,40,0,0),('2026-09-01',10,0,50,0,0),('2026-09-02',30,1,40,0,0),('2026-09-03',30,1,40,1,0),('2026-09-04',30,0,40,0,0),('2026-09-05',30,0,40,0,0),('2026-09-06',30,0,40,0,0),('2026-09-07',30,1,40,0,0),('2026-09-08',30,0,40,1,0),('2026-09-09',30,0,40,0,0),('2026-09-10',30,0,40,0,0),('2026-09-11',30,0,40,0,0),('2026-09-12',30,0,40,0,0),('2026-09-13',30,0,40,0,0),('2026-09-14',30,0,40,0,0),('2026-09-15',30,0,40,1,0),('2026-09-16',30,0,40,0,0),('2026-09-17',30,0,40,0,0),('2026-09-18',30,0,40,0,0),('2026-09-19',0,0,0,0,0),('2026-09-20',0,0,0,0,0),('2026-09-21',30,0,40,0,0),('2026-09-22',30,0,40,1,0),('2026-09-23',30,0,40,0,0),('2026-09-24',30,0,40,0,0),('2026-09-25',30,1,40,0,0),('2026-09-26',0,0,0,0,0),('2026-09-27',0,0,0,0,0),('2026-09-28',30,0,40,0,0),('2026-09-29',40,2,40,0,0),('2026-09-30',30,0,40,0,0),('2026-10-01',30,0,40,0,0),('2026-10-02',30,0,40,0,0),('2026-10-03',0,0,0,0,0),('2026-10-04',0,0,0,0,0),('2026-10-05',30,0,40,0,0),('2026-10-06',30,0,40,0,0),('2026-10-07',30,0,40,0,0),('2026-10-08',30,0,40,0,0),('2026-10-09',30,0,40,0,0),('2026-10-10',0,0,0,0,0),('2026-10-11',0,0,0,0,0),('2026-10-12',30,0,40,0,0),('2026-10-13',30,0,40,0,0),('2026-10-14',30,0,40,0,0),('2026-10-15',30,0,40,0,0),('2026-10-16',30,0,40,0,0),('2026-10-17',0,0,0,0,0),('2026-10-18',0,0,0,0,0),('2026-10-19',30,0,40,0,0),('2026-10-20',30,0,40,0,0),('2026-10-21',30,0,40,0,0),('2026-10-22',30,0,40,0,0),('2026-10-23',30,0,40,0,0),('2026-10-24',0,0,0,0,0),('2026-10-25',0,0,0,0,0);
/*!40000 ALTER TABLE `daily_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_token_counters`
--

DROP TABLE IF EXISTS `daily_token_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_token_counters` (
  `date` date NOT NULL,
  `priority_count` int DEFAULT '0',
  `normal_count` int DEFAULT '0',
  `wp_count` int DEFAULT '0',
  `wn_count` int DEFAULT '0',
  `ap_count` int DEFAULT '0',
  `an_count` int DEFAULT '0',
  `last_token` int DEFAULT '0',
  `wl_count` int DEFAULT '0',
  `al_count` int DEFAULT '0',
  `tokens_per_hour` int DEFAULT '40',
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_token_counters`
--

LOCK TABLES `daily_token_counters` WRITE;
/*!40000 ALTER TABLE `daily_token_counters` DISABLE KEYS */;
INSERT INTO `daily_token_counters` VALUES ('2026-07-29',0,0,0,0,0,0,0,0,0,10),('2026-07-30',0,0,0,0,0,0,0,0,0,10),('2026-07-31',0,0,0,0,0,0,0,0,0,10),('2026-08-03',0,0,0,0,0,0,0,0,0,10),('2026-08-04',0,0,0,0,0,0,0,0,0,10),('2026-08-05',0,0,0,0,0,0,0,0,0,10),('2026-08-06',0,0,0,0,0,0,0,0,0,10),('2026-08-07',0,0,0,0,0,0,0,0,0,10),('2026-08-10',0,0,0,0,0,0,0,0,0,10),('2026-08-11',0,0,0,0,0,0,0,0,0,10),('2026-08-12',0,0,0,0,0,0,0,0,0,10),('2026-08-13',0,0,0,0,0,0,0,0,0,10),('2026-08-14',0,0,0,0,0,0,0,0,0,10),('2026-08-17',0,0,0,0,0,0,0,0,0,10),('2026-08-18',0,0,0,0,0,0,0,0,0,10),('2026-08-19',0,0,0,0,2,0,2,0,0,10),('2026-08-20',0,0,0,0,0,0,0,0,0,10),('2026-08-21',0,0,0,0,0,1,1,0,0,10),('2026-08-24',0,0,0,0,0,0,0,0,0,10),('2026-08-25',0,0,0,0,0,0,0,0,0,10),('2026-08-27',0,0,0,0,0,0,0,0,0,10),('2026-08-28',0,0,0,0,0,0,0,0,0,10),('2026-09-01',0,0,0,0,0,0,0,0,0,10),('2026-09-02',0,0,0,0,0,1,1,0,0,30),('2026-09-03',0,0,0,1,0,1,2,0,0,30),('2026-09-07',0,0,0,0,0,1,1,0,0,30),('2026-09-08',0,0,0,1,0,0,1,0,0,30),('2026-09-11',0,0,0,0,0,0,0,0,0,10),('2026-09-15',0,0,0,1,0,0,1,0,0,30),('2026-09-22',0,0,0,1,0,0,1,0,0,30),('2026-09-25',0,0,0,0,0,1,1,0,0,30),('2026-09-29',0,0,0,0,0,2,2,0,0,30);
/*!40000 ALTER TABLE `daily_token_counters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_field_settings`
--

DROP TABLE IF EXISTS `dashboard_field_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_field_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dashboard` varchar(255) NOT NULL,
  `field_key` varchar(255) NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `display_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dashboard_field` (`dashboard`,`field_key`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_field_settings`
--

LOCK TABLES `dashboard_field_settings` WRITE;
/*!40000 ALTER TABLE `dashboard_field_settings` DISABLE KEYS */;
INSERT INTO `dashboard_field_settings` VALUES (1,'MANAGER','id',0,1),(2,'MANAGER','token',0,2),(3,'MANAGER','name',1,6),(4,'MANAGER','mobile',1,7),(5,'MANAGER','aadhaar_last4',1,3),(6,'MANAGER','age',1,9),(7,'MANAGER','gender',1,8),(8,'MANAGER','divyang',0,8),(9,'MANAGER','district',1,12),(10,'MANAGER','service_type',1,13),(11,'MANAGER','qrc',0,11),(12,'MANAGER','date',1,2),(13,'MANAGER','mode',0,13),(14,'MANAGER','priority',0,14),(15,'MANAGER','created_at',1,1),(16,'MANAGER','device_id',0,16),(17,'MANAGER','token_type',1,4),(18,'MANAGER','visited',0,18),(19,'MANAGER','visited_at',1,16),(20,'MANAGER','distance_meters',0,20),(21,'MANAGER','token_seq',0,21),(22,'MANAGER','entry_marked',0,22),(23,'MANAGER','entry_time',1,15),(24,'MANAGER','eid',0,24),(25,'MANAGER','identity_type',0,25),(26,'MANAGER','sid',0,26),(27,'MANAGER','hardware_fp',0,27),(28,'MANAGER','state',0,11),(29,'MANAGER','service_other',0,29),(30,'GUARD','id',0,1),(31,'GUARD','token',0,2),(32,'GUARD','name',1,6),(33,'GUARD','mobile',1,7),(34,'GUARD','aadhaar_last4',0,5),(35,'GUARD','age',1,9),(36,'GUARD','gender',1,8),(37,'GUARD','divyang',0,8),(38,'GUARD','district',1,12),(39,'GUARD','service_type',1,13),(40,'GUARD','qrc',0,11),(41,'GUARD','date',1,2),(42,'GUARD','mode',0,13),(43,'GUARD','priority',0,14),(44,'GUARD','created_at',1,1),(45,'GUARD','device_id',0,16),(46,'GUARD','token_type',1,4),(47,'GUARD','visited',0,18),(48,'GUARD','visited_at',0,16),(49,'GUARD','distance_meters',0,20),(50,'GUARD','token_seq',0,21),(51,'GUARD','entry_marked',0,22),(52,'GUARD','entry_time',0,15),(53,'GUARD','eid',0,24),(54,'GUARD','identity_type',0,25),(55,'GUARD','sid',0,26),(56,'GUARD','hardware_fp',0,27),(57,'GUARD','state',0,11),(58,'GUARD','service_other',0,29),(59,'GUARD2','id',0,1),(60,'GUARD2','token',0,2),(61,'GUARD2','name',1,6),(62,'GUARD2','mobile',1,7),(63,'GUARD2','aadhaar_last4',0,5),(64,'GUARD2','age',1,9),(65,'GUARD2','gender',1,8),(66,'GUARD2','divyang',0,8),(67,'GUARD2','district',1,12),(68,'GUARD2','service_type',1,13),(69,'GUARD2','qrc',0,11),(70,'GUARD2','date',1,2),(71,'GUARD2','mode',0,13),(72,'GUARD2','priority',0,14),(73,'GUARD2','created_at',1,1),(74,'GUARD2','device_id',0,16),(75,'GUARD2','token_type',1,4),(76,'GUARD2','visited',0,18),(77,'GUARD2','visited_at',1,16),(78,'GUARD2','distance_meters',0,20),(79,'GUARD2','token_seq',0,21),(80,'GUARD2','entry_marked',0,22),(81,'GUARD2','entry_time',1,15),(82,'GUARD2','eid',0,24),(83,'GUARD2','identity_type',0,25),(84,'GUARD2','sid',0,26),(85,'GUARD2','hardware_fp',0,27),(86,'GUARD2','state',0,11),(87,'GUARD2','service_other',0,29),(88,'MANAGER','token_count',1,3),(90,'MANAGER','identity',1,5),(91,'MANAGER','expected_time',1,14),(92,'MANAGER','time_taken',1,17),(93,'MANAGER','reference_of',1,18),(94,'GUARD','token_count',1,3),(96,'GUARD','expected_time',1,14),(97,'GUARD2','token_count',1,3),(99,'GUARD2','expected_time',0,14);
/*!40000 ALTER TABLE `dashboard_field_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `district_visit_history`
--

DROP TABLE IF EXISTS `district_visit_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `district_visit_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `mode` varchar(50) DEFAULT NULL,
  `eid_type` varchar(50) DEFAULT NULL,
  `visits` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `district_visit_history`
--

LOCK TABLES `district_visit_history` WRITE;
/*!40000 ALTER TABLE `district_visit_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `district_visit_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `districts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(255) DEFAULT NULL,
  `english_name` varchar(255) NOT NULL,
  `hindi_name` varchar(255) NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_state_english` (`state`,`english_name`)
) ENGINE=InnoDB AUTO_INCREMENT=276 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `districts`
--

LOCK TABLES `districts` WRITE;
/*!40000 ALTER TABLE `districts` DISABLE KEYS */;
INSERT INTO `districts` VALUES (248,'Kerala','Thiruvananthapuram','तिरुवनंतपुरम',1),(249,'Kerala','Kollam','कोल्लम',1),(250,'Kerala','Pathanamthitta','पथनमथिट्टा',1),(251,'Kerala','Alappuzha','अलप्पुझा',1),(252,'Kerala','Kottayam','कोट्टायम',1),(253,'Kerala','Idukki','इडुक्की',1),(254,'Kerala','Ernakulam','एर्नाकुलम',1),(255,'Kerala','Thrissur','त्रिशूर',1),(256,'Kerala','Palakkad','पालक्काड',1),(257,'Kerala','Malappuram','मलप्पुरम',1),(258,'Kerala','Kozhikode','कोझिकोड',1),(259,'Kerala','Wayanad','वायनाड',1),(260,'Kerala','Kannur','कन्नूर',1),(261,'Kerala','Kasaragod','कासरगोड',1),(266,'Lakshadweep','Agatti','अगत्ती',1),(267,'Lakshadweep','Amini','अमिनी',1),(268,'Lakshadweep','Andrott','अंद्रोट',1),(269,'Lakshadweep','Bitra','बित्रा',1),(270,'Lakshadweep','Chetlat','चेतलाट',1),(271,'Lakshadweep','Kadmat','कदमत',1),(272,'Lakshadweep','Kalpeni','कल्पेनी',1),(273,'Lakshadweep','Kavaratti','कवरत्ती',1),(274,'Lakshadweep','Kiltan','किल्तान',1),(275,'Lakshadweep','Minicoy','मिनिकॉय',1);
/*!40000 ALTER TABLE `districts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_settings`
--

DROP TABLE IF EXISTS `form_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `field_key` varchar(255) NOT NULL,
  `field_label` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `mandatory` tinyint(1) DEFAULT '1',
  `display_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `field_key` (`field_key`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_settings`
--

LOCK TABLES `form_settings` WRITE;
/*!40000 ALTER TABLE `form_settings` DISABLE KEYS */;
INSERT INTO `form_settings` VALUES (1,'qrc','QRC Number',0,0,1),(2,'name','Name',1,1,2),(3,'mobile','Mobile Number',1,1,3),(4,'aadhaar_last4','Aadhaar Last 4',1,1,4),(5,'gender','Gender',1,1,5),(6,'age','Age',1,1,6),(7,'district','District',1,1,7),(8,'identity','EID/SID Details',0,0,8),(9,'consent','Consent Checkbox',1,1,9),(10,'state','State',1,1,1);
/*!40000 ALTER TABLE `form_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geojson_settings`
--

DROP TABLE IF EXISTS `geojson_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `geojson_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` text NOT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `state` (`state`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geojson_settings`
--

LOCK TABLES `geojson_settings` WRITE;
/*!40000 ALTER TABLE `geojson_settings` DISABLE KEYS */;
INSERT INTO `geojson_settings` VALUES (12,'Kerala','kerala.geojson','/js/geojson/kerala.geojson','2026-08-18 06:29:06'),(13,'Lakshadweep','lakshadweep.geojson','/js/geojson/lakshadweep.geojson','2026-08-18 06:29:06');
/*!40000 ALTER TABLE `geojson_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `holidays` (
  `date` date NOT NULL,
  `reason` text,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holidays`
--

LOCK TABLES `holidays` WRITE;
/*!40000 ALTER TABLE `holidays` DISABLE KEYS */;
INSERT INTO `holidays` VALUES ('2026-03-04','Holi'),('2026-03-21','Id-ul-Fitr'),('2026-03-26','Ram Navmi'),('2026-03-31','Mahavir Jayanti'),('2026-04-03','Good Friday'),('2026-04-14','Ambedkar Jayanti'),('2026-05-01','Buddha Purnima'),('2026-05-28','Bakrid (Eid al-Adha)'),('2026-06-26','Muharram'),('2026-08-08','saturday'),('2026-08-09','sunday'),('2026-08-15','Independence Day'),('2026-08-16','Sunday'),('2026-08-26','Milad-un-nabi'),('2026-10-02','Gandhi Jayanti'),('2026-10-20','Dusshera'),('2026-11-08','Diwali'),('2026-11-24','Guru Nakak Jayanti'),('2026-12-25','Christmas Day');
/*!40000 ALTER TABLE `holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logo_settings`
--

DROP TABLE IF EXISTS `logo_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logo_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` text,
  `is_active` tinyint(1) DEFAULT '1',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logo_settings`
--

LOCK TABLES `logo_settings` WRITE;
/*!40000 ALTER TABLE `logo_settings` DISABLE KEYS */;
INSERT INTO `logo_settings` VALUES (1,'department_logo','logo.png','assets/logo/logo.png',1,'2026-07-28 13:32:58');
/*!40000 ALTER TABLE `logo_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notices` (
  `date` date NOT NULL,
  `message` text,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notices`
--

LOCK TABLES `notices` WRITE;
/*!40000 ALTER TABLE `notices` DISABLE KEYS */;
INSERT INTO `notices` VALUES ('2026-04-10','The Regional Office Lucknow shall remain closed on 14th April as it has been declared a holiday on account of birthday of Dr. B.R. Ambedkar/ डॉ. बी.आर. अंबेडकर के जन्मदिन के उपलक्ष्य में 14 अप्रैल को अवकाश घोषित होने के कारण क्षेत्रीय कार्यालय लखनऊ बंद रहेगा।'),('2026-04-13','The Regional Office Lucknow shall remain closed on 14th April as it has been declared a holiday on account of birthday of Dr. B.R. Ambedkar/ डॉ. बी.आर. अंबेडकर के जन्मदिन के उपलक्ष्य में 14 अप्रैल को अवकाश घोषित होने के कारण क्षेत्रीय कार्यालय लखनऊ बंद रहेगा।'),('2026-05-25','Dear Resident, This is to inform you that 28.05.2026 has been declared a holiday by the Central Government. Therefore, your appointment booked for 28.05.2026 is cancelled and you are requested to book an appointment on another date. We apologize for the inconvenience caused./ प्रिय निवासी, आपको अवगत कराना है कि दिनांक 28.05.2026 को केंद्र सरकार द्वारा अवकाश की घोषणा की गई है। अतएव आपके द्वारा बुक दिनांक 28.05.2026 की appointment को निरस्त किया जाता है साथ ही आपसे किसी अन्य तिथि में appointment बुक करने का आग्रह किया जाता है। आपको हुई असुविधा के लिए हमें खेद है।'),('2026-05-26','Dear Resident, This is to inform you that 28.05.2026 has been declared a holiday by the Central Government. Therefore, your appointment booked for 28.05.2026 is cancelled and you are requested to book an appointment on another date. We apologize for the inconvenience caused./ प्रिय निवासी, आपको अवगत कराना है कि दिनांक 28.05.2026 को केंद्र सरकार द्वारा अवकाश की घोषणा की गई है। अतएव आपके द्वारा बुक दिनांक 28.05.2026 की appointment को निरस्त किया जाता है साथ ही आपसे किसी अन्य तिथि में appointment बुक करने का आग्रह किया जाता है। आपको हुई असुविधा के लिए हमें खेद है।'),('2026-06-03','26-06-2026 is a declared holiday on account of Muharram/  मुहर्रम के उपलक्ष्य में 26-06-2026 को अवकाश घोषित किया गया है।');
/*!40000 ALTER TABLE `notices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_verifications`
--

DROP TABLE IF EXISTS `otp_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `otp_verifications` (
  `mobile` varchar(20) NOT NULL,
  `otp` varchar(20) DEFAULT NULL,
  `expires_at` bigint DEFAULT NULL,
  `attempts` int DEFAULT '0',
  `verified` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_verifications`
--

LOCK TABLES `otp_verifications` WRITE;
/*!40000 ALTER TABLE `otp_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `otp_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physical_reference_entries`
--

DROP TABLE IF EXISTS `physical_reference_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `physical_reference_entries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `aadhaar_last4` varchar(4) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `service_type` varchar(255) DEFAULT NULL,
  `token_type` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `token` varchar(100) DEFAULT NULL,
  `reference_of` varchar(255) DEFAULT NULL,
  `eid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physical_reference_entries`
--

LOCK TABLES `physical_reference_entries` WRITE;
/*!40000 ALTER TABLE `physical_reference_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `physical_reference_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priority_districts`
--

DROP TABLE IF EXISTS `priority_districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priority_districts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_state_district` (`state`,`district`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priority_districts`
--

LOCK TABLES `priority_districts` WRITE;
/*!40000 ALTER TABLE `priority_districts` DISABLE KEYS */;
INSERT INTO `priority_districts` VALUES (20,'Andhra Pradesh','Alluri Sitharama Raju'),(21,'Andhra Pradesh','Parvathipuram Manyam'),(22,'Andhra Pradesh','Srikakulam'),(23,'Andhra Pradesh','Vizianagaram'),(24,'Telangana','Adilabad'),(25,'Telangana','Kumuram Bheem Asifabad'),(26,'Telangana','Mulugu');
/*!40000 ALTER TABLE `priority_districts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priority_rules`
--

DROP TABLE IF EXISTS `priority_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priority_rules` (
  `rule_key` varchar(255) NOT NULL,
  `rule_value` text,
  PRIMARY KEY (`rule_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priority_rules`
--

LOCK TABLES `priority_rules` WRITE;
/*!40000 ALTER TABLE `priority_rules` DISABLE KEYS */;
INSERT INTO `priority_rules` VALUES ('appointment_days_visible','10'),('child_age_limit','5'),('default_appointment_slots',NULL),('default_tokens_per_hour',NULL),('default_walkin_slots',NULL),('female_priority_age','60'),('gazette_office_address','दिल्ली – ओल्ड सचिवालय, सिविल लाइंस'),('geo_end_1','10:00'),('geo_end_2','14:00'),('geo_start_1','05:30'),('geo_start_2','10:01'),('geofence_distance_meters','100'),('geofence_stop_hour','11'),('manager_future_days','10'),('manager_previous_days','1'),('office_display_en','This is for UIDAI SO Thiruvananthapuram, Door Sanchar Bhavan, PMG Junction, Thiruvananthapuram - 695033'),('office_display_hi','यह यूआईडीएआई एसओ तिरुवनंतपुरम, दूर संचार भवन, पीएमजी जंक्शन, तिरुवनंतपुरम - 695033 के लिए है'),('office_latitude','8.5105'),('office_longitude','76.9495'),('office_open_saturday','0'),('office_open_sunday','0'),('office_short_name','SO Thiruvananthapuram'),('senior_age_limit','60'),('today_appointment_cutoff_hour','07:30'),('walkin_end_hour','16:30'),('walkin_start_hour','09:30'),('watermark_text','SO-TRV');
/*!40000 ALTER TABLE `priority_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qr_settings`
--

DROP TABLE IF EXISTS `qr_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `qr_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `qr_type` varchar(255) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` text,
  `is_active` tinyint(1) DEFAULT '1',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `qr_type` (`qr_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qr_settings`
--

LOCK TABLES `qr_settings` WRITE;
/*!40000 ALTER TABLE `qr_settings` DISABLE KEYS */;
INSERT INTO `qr_settings` VALUES (1,'dob','dobqr.png','assets/QRs/dobqr.png',1,'2026-07-27 11:57:21'),(2,'name','nameqr.png','assets/QRs/nameqr.png',1,'2026-07-27 11:59:09'),(3,'reactivation','reactqr.png','assets/QRs/reactqr.png',1,'2026-07-29 18:01:51');
/*!40000 ALTER TABLE `qr_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_form_settings`
--

DROP TABLE IF EXISTS `service_form_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_form_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_type_id` int NOT NULL,
  `field_key` varchar(255) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `mandatory` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_service_form_service_type` (`service_type_id`),
  CONSTRAINT `fk_service_form_service_type` FOREIGN KEY (`service_type_id`) REFERENCES `service_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_form_settings`
--

LOCK TABLES `service_form_settings` WRITE;
/*!40000 ALTER TABLE `service_form_settings` DISABLE KEYS */;
INSERT INTO `service_form_settings` VALUES (1,3,'qrc',0,0),(2,6,'qrc',0,0),(3,11,'qrc',0,0),(4,1,'qrc',0,0),(5,4,'qrc',0,0),(6,7,'qrc',0,0),(7,5,'qrc',0,0),(8,2,'qrc',0,0),(9,12,'qrc',0,0),(10,13,'qrc',0,0),(11,3,'name',1,1),(12,6,'name',1,1),(13,11,'name',1,1),(14,1,'name',1,1),(15,4,'name',1,1),(16,7,'name',1,1),(17,5,'name',1,1),(18,2,'name',1,1),(19,12,'name',1,1),(20,13,'name',1,1),(21,3,'mobile',1,1),(22,6,'mobile',1,1),(23,11,'mobile',1,1),(24,1,'mobile',1,1),(25,4,'mobile',1,1),(26,7,'mobile',1,1),(27,5,'mobile',1,1),(28,2,'mobile',1,1),(29,12,'mobile',1,1),(30,13,'mobile',1,1),(31,3,'aadhaar_last4',1,1),(32,6,'aadhaar_last4',1,1),(33,11,'aadhaar_last4',1,1),(34,1,'aadhaar_last4',1,1),(35,4,'aadhaar_last4',1,1),(36,7,'aadhaar_last4',1,1),(37,5,'aadhaar_last4',1,1),(38,2,'aadhaar_last4',1,1),(39,12,'aadhaar_last4',1,1),(40,13,'aadhaar_last4',1,1),(41,3,'gender',1,1),(42,6,'gender',1,1),(43,11,'gender',1,1),(44,1,'gender',1,1),(45,4,'gender',1,1),(46,7,'gender',1,1),(47,5,'gender',1,1),(48,2,'gender',1,1),(49,12,'gender',1,1),(50,13,'gender',1,1),(51,3,'age',1,1),(52,6,'age',1,1),(53,11,'age',1,1),(54,1,'age',1,1),(55,4,'age',1,1),(56,7,'age',1,1),(57,5,'age',1,1),(58,2,'age',1,1),(59,12,'age',1,1),(60,13,'age',1,1),(61,3,'district',1,1),(62,6,'district',1,1),(63,11,'district',1,1),(64,1,'district',1,1),(65,4,'district',1,1),(66,7,'district',1,1),(67,5,'district',1,1),(68,2,'district',1,1),(69,12,'district',1,1),(70,13,'district',1,1),(71,3,'identity',1,1),(72,6,'identity',0,0),(73,11,'identity',0,0),(74,1,'identity',0,0),(75,4,'identity',0,0),(76,7,'identity',0,0),(77,5,'identity',0,0),(78,2,'identity',0,0),(79,12,'identity',0,0),(80,13,'identity',0,0),(81,3,'consent',1,1),(82,6,'consent',1,1),(83,11,'consent',1,1),(84,1,'consent',1,1),(85,4,'consent',1,1),(86,7,'consent',1,1),(87,5,'consent',1,1),(88,2,'consent',1,1),(89,12,'consent',1,1),(90,13,'consent',1,1),(91,3,'state',1,1),(92,6,'state',1,1),(93,11,'state',1,1),(94,1,'state',1,1),(95,4,'state',1,1),(96,7,'state',1,1),(97,5,'state',1,1),(98,2,'state',1,1),(99,12,'state',1,1),(100,13,'state',1,1);
/*!40000 ALTER TABLE `service_form_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_types`
--

DROP TABLE IF EXISTS `service_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `english_name` varchar(255) NOT NULL,
  `hindi_name` varchar(255) NOT NULL,
  `requires_eid` tinyint(1) DEFAULT '0',
  `requires_sid` tinyint(1) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `display_order` int DEFAULT '0',
  `requires_identity` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `english_name` (`english_name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_types`
--

LOCK TABLES `service_types` WRITE;
/*!40000 ALTER TABLE `service_types` DISABLE KEYS */;
INSERT INTO `service_types` VALUES (1,'DoB','जन्मतिथि',1,0,1,1,1),(2,'Name','नाम',1,0,1,2,1),(3,'Aadhaar Suspended','आधार कार्ड निलंबित',1,0,1,3,1),(4,'Gender','लिंग',1,0,1,4,1),(5,'Lost Aadhaar','आधार कार्ड खो गया',0,0,1,5,0),(6,'Biometric Issue','बायोमेट्रिक समस्या',1,0,1,6,1),(7,'Lock Aadhaar','आधार कार्ड लॉक',0,0,1,7,0),(11,'Cancelled','रद्द कर दिया ',0,0,1,0,0),(12,'New Enrolment','नया नामांकन',0,0,1,0,0),(13,'None of the above','इनमें से कोई नहीं',0,0,1,8,0);
/*!40000 ALTER TABLE `service_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` varchar(100) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `aadhaar_last4` varchar(4) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `divyang` varchar(50) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `service_type` varchar(255) DEFAULT NULL,
  `qrc` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `mode` varchar(50) DEFAULT NULL,
  `priority` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `device_id` varchar(255) DEFAULT NULL,
  `token_type` varchar(50) DEFAULT NULL,
  `visited` tinyint(1) DEFAULT '0',
  `visited_at` datetime DEFAULT NULL,
  `distance_meters` int DEFAULT NULL,
  `token_seq` int DEFAULT NULL,
  `entry_marked` tinyint(1) DEFAULT '0',
  `entry_time` datetime DEFAULT NULL,
  `eid` varchar(100) DEFAULT NULL,
  `identity_type` varchar(100) DEFAULT NULL,
  `sid` varchar(100) DEFAULT NULL,
  `hardware_fp` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `service_other` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_token_seq_per_day` (`date`,`token_seq`),
  KEY `idx_tokens_date` (`date`),
  KEY `idx_tokens_visited` (`visited`),
  KEY `idx_tokens_service` (`service_type`),
  KEY `idx_tokens_mode` (`mode`)
) ENGINE=InnoDB AUTO_INCREMENT=2140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (2129,'002-AP-8844','akram','9998888884','8844',99,'Male',NULL,'Kadmat','Cancelled','','2026-08-19','A','P','2026-08-18 13:42:44','DEV-38c2520e-dccb-4507-bf27-21f71d6c7604','AP',0,NULL,0,2,0,NULL,NULL,NULL,NULL,'HW-835c2912ee40e60582ff7ba3590c85945e815c15abf3a97f5671b98cb3181867','Lakshadweep',NULL),(2130,'001-AN-3700','Sofji','9895939397','3700',43,'Female',NULL,'Thiruvananthapuram','Cancelled','','2026-09-02','A','N','2026-09-01 11:55:19','DEV-ff1d61ca-aa2b-4999-bbcd-439ac9f2acb5','AN',0,NULL,181,1,0,NULL,NULL,NULL,NULL,'HW-a34bd3e3fcc3d7afd1412dc462b300e4a8ec7e22c942d93b0fe78a5d775b4170','Kerala',NULL),(2131,'001-AN-0372','Balaji','9150440321','0372',30,'Male',NULL,'Thiruvananthapuram','Biometric Issue','','2026-09-07','A','N','2026-09-01 11:59:17','DEV-3f611eb7-ae0e-4865-8611-7f4d11207f38','AN',0,NULL,185,1,0,NULL,NULL,NULL,NULL,'HW-857a0070555944f043c8de86c21beac4b08c4c921c57e8cc986341cf7bfc0138','Kerala',NULL),(2132,'001-AN-6938','Srini','9150440321','6938',58,'Male',NULL,'Kasaragod','Name','','2026-09-03','A','N','2026-09-01 12:02:20','DEV-3f611eb7-ae0e-4865-8611-7f4d11207f38','AN',0,NULL,182,1,0,NULL,NULL,NULL,NULL,'HW-857a0070555944f043c8de86c21beac4b08c4c921c57e8cc986341cf7bfc0138','Kerala',NULL),(2133,'002-WN-6256','Annu johnson','6238586321','6256',22,'Female',NULL,'Idukki','Biometric Issue','','2026-09-03','W','N','2026-09-03 15:41:05','DEV-215a493f-2f00-43a2-ba8d-4c9ff8be8b4d','WN',0,NULL,0,2,0,NULL,NULL,NULL,NULL,'HW-7134c1e610ea5852cecfea44311ff58249a51df2f271b374a1d0f330f0d1f624','Kerala',NULL),(2134,'001-WN-6985','Balaji','9150440321','6985',30,'Male',NULL,'Kollam','Gender','','2026-09-08','W','N','2026-09-08 14:53:01','DEV-3f611eb7-ae0e-4865-8611-7f4d11207f38','WN',0,NULL,182,1,0,NULL,NULL,NULL,NULL,'HW-857a0070555944f043c8de86c21beac4b08c4c921c57e8cc986341cf7bfc0138','Kerala',NULL),(2135,'001-WN-5585','Ameet maurya','8691963370','5585',22,'Male',NULL,'Kozhikode','Cancelled','','2026-09-15','W','N','2026-09-15 15:27:39','DEV-580e9037-44f8-4d66-aa79-f5ad3fd66251','WN',0,NULL,0,1,0,NULL,NULL,NULL,NULL,'HW-f11d38bb36f9b3f0bc66c570bea6985166880ff0c40ac51e1c6bfe6d7eaacb6e','Kerala',NULL),(2136,'001-WN-4342','Shreeya Pandey','8172772172','4342',32,'Female',NULL,'Kottayam','Aadhaar Suspended','','2026-09-22','W','N','2026-09-22 15:28:24','DEV-0aeec416-b202-4d3b-9c63-fd2f6f33eb7e','WN',1,'2026-09-22 15:33:11',2085797,1,1,'2026-09-22 15:28:58',NULL,'SID','S329832932442343245667776565','HW-417c8e2419c166398c6b6f78de7bea8858205cceaf63bfe700cfc0be2706d978','Kerala',NULL),(2137,'001-AN-4544','sheero test','9863553533','4544',23,'Female',NULL,'Minicoy','Lock Aadhaar','','2026-09-25','A','N','2026-09-22 16:49:54','DEV-0aeec416-b202-4d3b-9c63-fd2f6f33eb7e','AN',0,NULL,2085797,1,0,NULL,NULL,NULL,NULL,'HW-417c8e2419c166398c6b6f78de7bea8858205cceaf63bfe700cfc0be2706d978','Lakshadweep',NULL),(2138,'001-AN-5434','Shreeya Pandey','8707024848','5434',23,'Female',NULL,'Bitra','Aadhaar Suspended','','2026-09-29','A','N','2026-09-24 16:54:53','DEV-2fb8c426-750e-4177-b0bf-2efd72d1f44d','AN',0,NULL,19,1,0,NULL,NULL,'SID','S122991000773363633333334445','HW-417c8e2419c166398c6b6f78de7bea8858205cceaf63bfe700cfc0be2706d978','Lakshadweep',NULL),(2139,'002-AN-9762','Thrilik','9424353171','9762',8,'Male',NULL,'Thrissur','Name','','2026-09-29','A','N','2026-09-25 11:42:50','DEV-76c90d2c-c2e9-4411-9029-d92dcede425d','AN',0,NULL,0,2,0,NULL,NULL,NULL,NULL,'HW-9f81bd3cf04979b52929e1a0ab2dd3e7cb280887f08d48358f47ac2bd44d503e','Kerala',NULL);
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(100) NOT NULL,
  `session_name` varchar(255) NOT NULL,
  `page` varchar(255) NOT NULL,
  `recovery_code` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Counter No - 5','$2b$10$KsmeFg5IPDrIKmP24kb04un63RkQDB0Wpxk6EY4H7sFaBb9hxlQP2','SERVICE_COUNTER','GUARD2_SESSION','guard2.html',NULL,1),(2,'admin','$2b$10$ucRfut8dR86M2Q7rY.R5EeerjAAcYQBp4k9ILfq//owlxAI6fzuRa','MANAGER','MANAGER_SESSION','manager.html','LkoTS#110726',1),(3,'guard','$2b$10$Tl2NZ8Ft88YE31Cfi7VF/OhuTnWZpL2V8A32GrzqmQeJdiyKcSfw2','GUARD','GUARD_SESSION','guard.html',NULL,1),(4,'guard3','$2b$10$FtyMKuOCBMrvO.aSm2/f6.q9BJ1kyEzb/XiaOCaBB5gZ3vlTxxLG6','GUARD3','GUARD3_SESSION','guard3.html',NULL,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weekday_slot_rules`
--

DROP TABLE IF EXISTS `weekday_slot_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weekday_slot_rules` (
  `weekday` int NOT NULL,
  `weekday_name` varchar(50) NOT NULL,
  `appointment_total` int NOT NULL,
  `walkin_total` int NOT NULL,
  `tokens_per_hour` int DEFAULT '30',
  `work_start_time` time DEFAULT NULL,
  PRIMARY KEY (`weekday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekday_slot_rules`
--

LOCK TABLES `weekday_slot_rules` WRITE;
/*!40000 ALTER TABLE `weekday_slot_rules` DISABLE KEYS */;
INSERT INTO `weekday_slot_rules` VALUES (0,'Sunday',0,0,10,'11:00:00'),(1,'Monday',31,40,10,'09:30:00'),(2,'Tuesday',30,40,10,'09:30:00'),(3,'Wednesday',30,40,10,'09:30:00'),(4,'Thursday',30,40,10,'09:30:00'),(5,'Friday',30,40,10,'09:30:00'),(6,'Saturday',0,0,10,'11:00:00');
/*!40000 ALTER TABLE `weekday_slot_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_days`
--

DROP TABLE IF EXISTS `working_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_days` (
  `date` date NOT NULL,
  `reason` text,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_days`
--

LOCK TABLES `working_days` WRITE;
/*!40000 ALTER TABLE `working_days` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_days` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-26  8:50:02
