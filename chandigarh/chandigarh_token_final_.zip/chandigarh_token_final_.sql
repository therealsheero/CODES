-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: generatetoken-mysql.mysql.database.azure.com    Database: chandigarh_token
-- ------------------------------------------------------
-- Server version	8.0.46-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `daily_slots`
--

DROP TABLE IF EXISTS `daily_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_slots` (
  `date` date NOT NULL,
  `appointment_total` int DEFAULT NULL,
  `appointment_booked` int DEFAULT '0',
  `walkin_total` int DEFAULT NULL,
  `walkin_booked` int DEFAULT '0',
  `carry_forward_done` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_slots`
--

LOCK TABLES `daily_slots` WRITE;
/*!40000 ALTER TABLE `daily_slots` DISABLE KEYS */;
INSERT INTO `daily_slots` VALUES ('2026-09-26',0,0,0,0,0),('2026-09-27',0,0,0,0,0),('2026-09-28',210,1,90,0,0),('2026-09-29',210,0,90,0,0),('2026-09-30',210,0,90,0,0),('2026-10-01',210,0,90,0,0),('2026-10-02',210,0,90,0,0),('2026-10-03',0,0,0,0,0),('2026-10-04',0,0,0,0,0),('2026-10-05',210,0,90,0,0),('2026-10-06',210,0,90,0,0),('2026-10-07',210,0,90,0,0),('2026-10-08',210,0,90,0,0),('2026-10-09',210,0,90,0,0),('2026-10-10',0,0,0,0,0),('2026-10-11',0,0,0,0,0),('2026-10-12',210,0,90,0,0),('2026-10-13',210,0,90,0,0),('2026-10-14',210,0,90,0,0),('2026-10-15',210,0,90,0,0),('2026-10-16',210,0,90,0,0),('2026-10-17',0,0,0,0,0),('2026-10-18',0,0,0,0,0),('2026-10-19',210,0,90,0,0),('2026-10-20',210,0,90,0,0),('2026-10-21',210,0,90,0,0),('2026-10-22',210,0,90,0,0),('2026-10-23',210,0,90,0,0),('2026-10-24',0,0,0,0,0),('2026-10-25',0,0,0,0,0),('2026-10-26',210,0,90,0,0);
/*!40000 ALTER TABLE `daily_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_token_counters`
--

DROP TABLE IF EXISTS `daily_token_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_token_counters` (
  `date` date NOT NULL,
  `priority_count` int DEFAULT '0',
  `normal_count` int DEFAULT '0',
  `wp_count` int DEFAULT '0',
  `wn_count` int DEFAULT '0',
  `ap_count` int DEFAULT '0',
  `an_count` int DEFAULT '0',
  `last_token` int DEFAULT '0',
  `wl_count` int DEFAULT '0',
  `al_count` int DEFAULT '0',
  `tokens_per_hour` int DEFAULT '40',
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_token_counters`
--

LOCK TABLES `daily_token_counters` WRITE;
/*!40000 ALTER TABLE `daily_token_counters` DISABLE KEYS */;
INSERT INTO `daily_token_counters` VALUES ('2026-09-28',0,0,0,0,0,1,1,0,0,30);
/*!40000 ALTER TABLE `daily_token_counters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_field_settings`
--

DROP TABLE IF EXISTS `dashboard_field_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_field_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dashboard` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `display_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dashboard_field` (`dashboard`,`field_key`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_field_settings`
--

LOCK TABLES `dashboard_field_settings` WRITE;
/*!40000 ALTER TABLE `dashboard_field_settings` DISABLE KEYS */;
INSERT INTO `dashboard_field_settings` VALUES (1,'MANAGER','id',0,1),(2,'MANAGER','token',0,2),(3,'MANAGER','name',1,6),(4,'MANAGER','mobile',1,7),(5,'MANAGER','aadhaar_last4',1,3),(6,'MANAGER','age',1,9),(7,'MANAGER','gender',1,8),(8,'MANAGER','divyang',0,8),(9,'MANAGER','district',1,12),(10,'MANAGER','service_type',1,13),(11,'MANAGER','qrc',0,11),(12,'MANAGER','date',1,2),(13,'MANAGER','mode',0,13),(14,'MANAGER','priority',0,14),(15,'MANAGER','created_at',1,1),(16,'MANAGER','device_id',0,16),(17,'MANAGER','token_type',1,4),(18,'MANAGER','visited',0,18),(19,'MANAGER','visited_at',1,16),(20,'MANAGER','distance_meters',0,20),(21,'MANAGER','token_seq',0,21),(22,'MANAGER','entry_marked',0,22),(23,'MANAGER','entry_time',1,15),(24,'MANAGER','eid',0,24),(25,'MANAGER','identity_type',0,25),(26,'MANAGER','sid',0,26),(27,'MANAGER','hardware_fp',0,27),(28,'MANAGER','state',0,11),(29,'MANAGER','service_other',0,29),(30,'GUARD','id',0,1),(31,'GUARD','token',0,2),(32,'GUARD','name',1,6),(33,'GUARD','mobile',1,7),(34,'GUARD','aadhaar_last4',0,5),(35,'GUARD','age',1,9),(36,'GUARD','gender',1,8),(37,'GUARD','divyang',0,8),(38,'GUARD','district',1,12),(39,'GUARD','service_type',1,13),(40,'GUARD','qrc',0,11),(41,'GUARD','date',1,2),(42,'GUARD','mode',0,13),(43,'GUARD','priority',0,14),(44,'GUARD','created_at',1,1),(45,'GUARD','device_id',0,16),(46,'GUARD','token_type',1,4),(47,'GUARD','visited',0,18),(48,'GUARD','visited_at',0,16),(49,'GUARD','distance_meters',0,20),(50,'GUARD','token_seq',0,21),(51,'GUARD','entry_marked',0,22),(52,'GUARD','entry_time',0,15),(53,'GUARD','eid',0,24),(54,'GUARD','identity_type',0,25),(55,'GUARD','sid',0,26),(56,'GUARD','hardware_fp',0,27),(57,'GUARD','state',0,11),(58,'GUARD','service_other',0,29),(59,'GUARD2','id',0,1),(60,'GUARD2','token',0,2),(61,'GUARD2','name',1,6),(62,'GUARD2','mobile',1,7),(63,'GUARD2','aadhaar_last4',0,5),(64,'GUARD2','age',1,9),(65,'GUARD2','gender',1,8),(66,'GUARD2','divyang',0,8),(67,'GUARD2','district',1,12),(68,'GUARD2','service_type',1,13),(69,'GUARD2','qrc',0,11),(70,'GUARD2','date',1,2),(71,'GUARD2','mode',0,13),(72,'GUARD2','priority',0,14),(73,'GUARD2','created_at',1,1),(74,'GUARD2','device_id',0,16),(75,'GUARD2','token_type',1,4),(76,'GUARD2','visited',0,18),(77,'GUARD2','visited_at',1,16),(78,'GUARD2','distance_meters',0,20),(79,'GUARD2','token_seq',0,21),(80,'GUARD2','entry_marked',0,22),(81,'GUARD2','entry_time',1,15),(82,'GUARD2','eid',0,24),(83,'GUARD2','identity_type',0,25),(84,'GUARD2','sid',0,26),(85,'GUARD2','hardware_fp',0,27),(86,'GUARD2','state',0,11),(87,'GUARD2','service_other',0,29),(88,'MANAGER','token_count',1,3),(90,'MANAGER','identity',1,5),(91,'MANAGER','expected_time',1,14),(92,'MANAGER','time_taken',1,17),(93,'MANAGER','reference_of',1,18),(94,'GUARD','token_count',1,3),(96,'GUARD','expected_time',1,14),(97,'GUARD2','token_count',1,3),(99,'GUARD2','expected_time',0,14);
/*!40000 ALTER TABLE `dashboard_field_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `district_visit_history`
--

DROP TABLE IF EXISTS `district_visit_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `district_visit_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `district` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mode` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eid_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visits` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `district_visit_history`
--

LOCK TABLES `district_visit_history` WRITE;
/*!40000 ALTER TABLE `district_visit_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `district_visit_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `districts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `english_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hindi_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_state_english` (`state`,`english_name`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `districts`
--

LOCK TABLES `districts` WRITE;
/*!40000 ALTER TABLE `districts` DISABLE KEYS */;
INSERT INTO `districts` VALUES (1,'Chandigarh','Chandigarh','चंडीगढ़',1),(2,'Punjab','Amritsar','अमृतसर',1),(3,'Punjab','Barnala','बरनाला',1),(4,'Punjab','Bathinda','बठिंडा',1),(5,'Punjab','Faridkot','फरीदकोट',1),(6,'Punjab','Fatehgarh Sahib','फतेहगढ़ साहिब',1),(7,'Punjab','Fazilka','फाजिल्का',1),(8,'Punjab','Ferozepur','फिरोजपुर',1),(9,'Punjab','Gurdaspur','गुरदासपुर',1),(10,'Punjab','Hoshiarpur','होशियारपुर',1),(11,'Punjab','Jalandhar','जालंधर',1),(12,'Punjab','Kapurthala','कपूरथला',1),(13,'Punjab','Ludhiana','लुधियाना',1),(14,'Punjab','Malerkotla','मलेरकोटला',1),(15,'Punjab','Mansa','मानसा',1),(16,'Punjab','Moga','मोगा',1),(17,'Punjab','Pathankot','पठानकोट',1),(18,'Punjab','Patiala','पटियाला',1),(19,'Punjab','Rupnagar','रूपनगर',1),(20,'Punjab','Sahibzada Ajit Singh Nagar','साहिबजादा अजीत सिंह नगर',1),(21,'Punjab','Sangrur','संगरूर',1),(22,'Punjab','Shahid Bhagat Singh Nagar','शहीद भगत सिंह नगर',1),(23,'Punjab','Sri Muktsar Sahib','श्री मुक्तसर साहिब',1),(24,'Punjab','Tarn Taran','तरन तारन',1),(25,'Haryana','Ambala','अंबाला',1),(26,'Haryana','Bhiwani','भिवानी',1),(27,'Haryana','Charkhi Dadri','चरखी दादरी',1),(28,'Haryana','Faridabad','फरीदाबाद',1),(29,'Haryana','Fatehabad','फतेहाबाद',1),(30,'Haryana','Gurugram','गुरुग्राम',1),(31,'Haryana','Hisar','हिसार',1),(32,'Haryana','Jhajjar','झज्जर',1),(33,'Haryana','Jind','जींद',1),(34,'Haryana','Kaithal','कैथल',1),(35,'Haryana','Karnal','करनाल',1),(36,'Haryana','Kurukshetra','कुरुक्षेत्र',1),(37,'Haryana','Mahendragarh','महेंद्रगढ़',1),(38,'Haryana','Nuh','नूंह',1),(39,'Haryana','Palwal','पलवल',1),(40,'Haryana','Panchkula','पंचकूला',1),(41,'Haryana','Panipat','पानीपत',1),(42,'Haryana','Rewari','रेवाड़ी',1),(43,'Haryana','Rohtak','रोहतक',1),(44,'Haryana','Sirsa','सिरसा',1),(45,'Haryana','Sonipat','सोनीपत',1),(46,'Haryana','Yamunanagar','यमुनानगर',1),(47,'Himachal Pradesh','Bilaspur','बिलासपुर',1),(48,'Himachal Pradesh','Chamba','चंबा',1),(49,'Himachal Pradesh','Hamirpur','हमीरपुर',1),(50,'Himachal Pradesh','Kangra','कांगड़ा',1),(51,'Himachal Pradesh','Kinnaur','किन्नौर',1),(52,'Himachal Pradesh','Kullu','कुल्लू',1),(53,'Himachal Pradesh','Lahaul and Spiti','लाहौल और स्पीति',1),(54,'Himachal Pradesh','Mandi','मंडी',1),(55,'Himachal Pradesh','Shimla','शिमला',1),(56,'Himachal Pradesh','Sirmaur','सिरमौर',1),(57,'Himachal Pradesh','Solan','सोलन',1),(58,'Himachal Pradesh','Una','ऊना',1),(59,'Jammu and Kashmir','Anantnag','अनंतनाग',1),(60,'Jammu and Kashmir','Bandipora','बांदीपोरा',1),(61,'Jammu and Kashmir','Baramulla','बारामूला',1),(62,'Jammu and Kashmir','Budgam','बडगाम',1),(63,'Jammu and Kashmir','Doda','डोडा',1),(64,'Jammu and Kashmir','Ganderbal','गांदरबल',1),(65,'Jammu and Kashmir','Jammu','जम्मू',1),(66,'Jammu and Kashmir','Kathua','कठुआ',1),(67,'Jammu and Kashmir','Kishtwar','किश्तवाड़',1),(68,'Jammu and Kashmir','Kulgam','कुलगाम',1),(69,'Jammu and Kashmir','Kupwara','कुपवाड़ा',1),(70,'Jammu and Kashmir','Poonch','पुंछ',1),(71,'Jammu and Kashmir','Pulwama','पुलवामा',1),(72,'Jammu and Kashmir','Rajouri','राजौरी',1),(73,'Jammu and Kashmir','Ramban','रामबन',1),(74,'Jammu and Kashmir','Reasi','रियासी',1),(75,'Jammu and Kashmir','Samba','सांबा',1),(76,'Jammu and Kashmir','Shopian','शोपियां',1),(77,'Jammu and Kashmir','Srinagar','श्रीनगर',1),(78,'Jammu and Kashmir','Udhampur','उधमपुर',1),(79,'Ladakh','Leh','लेह',1),(80,'Ladakh','Kargil','कारगिल',1),(81,'Ladakh','Nubra','नुब्रा',1),(82,'Ladakh','Sham','शाम',1),(83,'Ladakh','Changthang','चांगथांग',1),(84,'Ladakh','Zanskar','ज़ांस्कर',1),(85,'Ladakh','Drass','द्रास',1);
/*!40000 ALTER TABLE `districts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_settings`
--

DROP TABLE IF EXISTS `form_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `field_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `mandatory` tinyint(1) DEFAULT '1',
  `display_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `field_key` (`field_key`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_settings`
--

LOCK TABLES `form_settings` WRITE;
/*!40000 ALTER TABLE `form_settings` DISABLE KEYS */;
INSERT INTO `form_settings` VALUES (1,'qrc','QRC Number',0,0,1),(2,'name','Name',1,1,2),(3,'mobile','Mobile Number',1,1,3),(4,'aadhaar_last4','Aadhaar Last 4',1,1,4),(5,'gender','Gender',1,1,5),(6,'age','Age',1,1,6),(7,'district','District',1,1,7),(8,'identity','EID/SID Details',0,0,8),(9,'consent','Consent Checkbox',1,1,9),(10,'state','State',1,1,1);
/*!40000 ALTER TABLE `form_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geojson_settings`
--

DROP TABLE IF EXISTS `geojson_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `geojson_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `state` (`state`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geojson_settings`
--

LOCK TABLES `geojson_settings` WRITE;
/*!40000 ALTER TABLE `geojson_settings` DISABLE KEYS */;
INSERT INTO `geojson_settings` VALUES (1,'Chandigarh','chandigarh.geojson','/js/geojson/chandigarh.geojson','2026-09-26 10:04:49'),(2,'Haryana','haryana.geojson','/js/geojson/haryana.geojson','2026-09-26 10:04:49'),(3,'Himachal Pradesh','himachal-pradesh.geojson','/js/geojson/himachal-pradesh.geojson','2026-09-26 10:04:49'),(4,'Jammu and Kashmir','jammu-and-kashmir.geojson','/js/geojson/jammu-and-kashmir.geojson','2026-09-26 10:04:49'),(5,'Ladakh','ladakh.geojson','/js/geojson/ladakh.geojson','2026-09-26 10:04:49'),(6,'Punjab','punjab.geojson','/js/geojson/punjab.geojson','2026-09-26 10:04:49');
/*!40000 ALTER TABLE `geojson_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `holidays` (
  `date` date NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holidays`
--

LOCK TABLES `holidays` WRITE;
/*!40000 ALTER TABLE `holidays` DISABLE KEYS */;
INSERT INTO `holidays` VALUES ('2026-01-26','Republic Day'),('2026-03-21','Id-ul-Fitr'),('2026-03-31','Mahavir Jayanti'),('2026-04-03','Good Friday'),('2026-05-01','Buddha Purnima'),('2026-05-27','Id-ul-Zuha (Bakrid)'),('2026-06-26','Muharram'),('2026-08-15','Independence Day'),('2026-08-26','Milad-un-Nabi / Id-e-Milad'),('2026-09-04','Janmashtami (Vaishnava)'),('2026-10-02','Mahatma Gandhi\'s Birthday'),('2026-10-20','Dussehra (Vijay Dashami)'),('2026-11-08','Diwali (Deepavali)'),('2026-11-24','Guru Nanak\'s Birthday'),('2026-12-25','Christmas Day');
/*!40000 ALTER TABLE `holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logo_settings`
--

DROP TABLE IF EXISTS `logo_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logo_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logo_settings`
--

LOCK TABLES `logo_settings` WRITE;
/*!40000 ALTER TABLE `logo_settings` DISABLE KEYS */;
INSERT INTO `logo_settings` VALUES (1,'department_logo','logo.png','assets/logo/logo.png',1,'2026-07-28 13:32:58');
/*!40000 ALTER TABLE `logo_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notices` (
  `date` date NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notices`
--

LOCK TABLES `notices` WRITE;
/*!40000 ALTER TABLE `notices` DISABLE KEYS */;
INSERT INTO `notices` VALUES ('2026-04-10','The Regional Office Lucknow shall remain closed on 14th April as it has been declared a holiday on account of birthday of Dr. B.R. Ambedkar/ डॉ. बी.आर. अंबेडकर के जन्मदिन के उपलक्ष्य में 14 अप्रैल को अवकाश घोषित होने के कारण क्षेत्रीय कार्यालय लखनऊ बंद रहेगा।'),('2026-04-13','The Regional Office Lucknow shall remain closed on 14th April as it has been declared a holiday on account of birthday of Dr. B.R. Ambedkar/ डॉ. बी.आर. अंबेडकर के जन्मदिन के उपलक्ष्य में 14 अप्रैल को अवकाश घोषित होने के कारण क्षेत्रीय कार्यालय लखनऊ बंद रहेगा।'),('2026-05-25','Dear Resident, This is to inform you that 28.05.2026 has been declared a holiday by the Central Government. Therefore, your appointment booked for 28.05.2026 is cancelled and you are requested to book an appointment on another date. We apologize for the inconvenience caused./ प्रिय निवासी, आपको अवगत कराना है कि दिनांक 28.05.2026 को केंद्र सरकार द्वारा अवकाश की घोषणा की गई है। अतएव आपके द्वारा बुक दिनांक 28.05.2026 की appointment को निरस्त किया जाता है साथ ही आपसे किसी अन्य तिथि में appointment बुक करने का आग्रह किया जाता है। आपको हुई असुविधा के लिए हमें खेद है।'),('2026-05-26','Dear Resident, This is to inform you that 28.05.2026 has been declared a holiday by the Central Government. Therefore, your appointment booked for 28.05.2026 is cancelled and you are requested to book an appointment on another date. We apologize for the inconvenience caused./ प्रिय निवासी, आपको अवगत कराना है कि दिनांक 28.05.2026 को केंद्र सरकार द्वारा अवकाश की घोषणा की गई है। अतएव आपके द्वारा बुक दिनांक 28.05.2026 की appointment को निरस्त किया जाता है साथ ही आपसे किसी अन्य तिथि में appointment बुक करने का आग्रह किया जाता है। आपको हुई असुविधा के लिए हमें खेद है।'),('2026-06-03','26-06-2026 is a declared holiday on account of Muharram/  मुहर्रम के उपलक्ष्य में 26-06-2026 को अवकाश घोषित किया गया है।');
/*!40000 ALTER TABLE `notices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_verifications`
--

DROP TABLE IF EXISTS `otp_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `otp_verifications` (
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` bigint DEFAULT NULL,
  `attempts` int DEFAULT '0',
  `verified` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_verifications`
--

LOCK TABLES `otp_verifications` WRITE;
/*!40000 ALTER TABLE `otp_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `otp_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physical_reference_entries`
--

DROP TABLE IF EXISTS `physical_reference_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `physical_reference_entries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aadhaar_last4` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_of` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physical_reference_entries`
--

LOCK TABLES `physical_reference_entries` WRITE;
/*!40000 ALTER TABLE `physical_reference_entries` DISABLE KEYS */;
INSERT INTO `physical_reference_entries` VALUES (1,'Shreeya Pandey',23,'8707027953','3232','Female','Ladakh','Leh','Aadhaar Suspended','Physical Token','2026-09-26 11:11:14','001-PT-3232','',NULL);
/*!40000 ALTER TABLE `physical_reference_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priority_districts`
--

DROP TABLE IF EXISTS `priority_districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priority_districts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_state_district` (`state`,`district`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priority_districts`
--

LOCK TABLES `priority_districts` WRITE;
/*!40000 ALTER TABLE `priority_districts` DISABLE KEYS */;
/*!40000 ALTER TABLE `priority_districts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priority_rules`
--

DROP TABLE IF EXISTS `priority_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priority_rules` (
  `rule_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rule_value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`rule_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priority_rules`
--

LOCK TABLES `priority_rules` WRITE;
/*!40000 ALTER TABLE `priority_rules` DISABLE KEYS */;
INSERT INTO `priority_rules` VALUES ('appointment_days_visible','10'),('child_age_limit','5'),('default_appointment_slots',NULL),('default_tokens_per_hour',NULL),('default_walkin_slots',NULL),('female_priority_age','60'),('gazette_office_address','SCO 95-98, Ground and Second Floor, Sector 17-B, Chandigarh 160017'),('geo_end_1','10:00'),('geo_end_2','16:00'),('geo_start_1','06:00'),('geo_start_2','10:00'),('geofence_distance_meters','100'),('manager_future_days','13'),('manager_previous_days','1'),('office_display_en','This is for UIDAI Regional Office Chandigarh, SCO 95-98, Ground and Second Floor, Sector 17-B, Chandigarh 160017'),('office_display_hi','यह UIDAI क्षेत्रीय कार्यालय चंडीगढ़, SCO 95-98, ग्राउंड और सेकंड फ्लोर, सेक्टर 17-B, चंडीगढ़ 160017 के लिए है।'),('office_latitude','30.740632'),('office_longitude','76.787979'),('office_open_saturday','0'),('office_open_sunday','0'),('office_opening_time','09:30'),('office_short_name','RO Chandigarh'),('senior_age_limit','60'),('today_appointment_cutoff_hour','06:00'),('walkin_end_hour','16:00'),('walkin_start_hour','06:00'),('watermark_text','RO-CHD');
/*!40000 ALTER TABLE `priority_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qr_settings`
--

DROP TABLE IF EXISTS `qr_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `qr_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `qr_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `qr_type` (`qr_type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qr_settings`
--

LOCK TABLES `qr_settings` WRITE;
/*!40000 ALTER TABLE `qr_settings` DISABLE KEYS */;
INSERT INTO `qr_settings` VALUES (1,'dob','dobqr.png','assets/QRs/dobqr.png',1,'2026-07-27 11:57:21'),(2,'name','nameqr.png','assets/QRs/nameqr.png',1,'2026-07-27 11:59:09'),(3,'reactivation','reactqr.png','assets/QRs/reactqr.png',1,'2026-07-29 18:01:51'),(4,'react','reactqr.png','assets/QRs/reactqr.png',1,'2026-09-26 10:14:19');
/*!40000 ALTER TABLE `qr_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_form_settings`
--

DROP TABLE IF EXISTS `service_form_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_form_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_type_id` int NOT NULL,
  `field_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `mandatory` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_service_form_service_type` (`service_type_id`),
  CONSTRAINT `fk_service_form_service_type` FOREIGN KEY (`service_type_id`) REFERENCES `service_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_form_settings`
--

LOCK TABLES `service_form_settings` WRITE;
/*!40000 ALTER TABLE `service_form_settings` DISABLE KEYS */;
INSERT INTO `service_form_settings` VALUES (1,4,'state',1,1),(2,4,'qrc',1,1),(3,4,'name',1,1),(4,4,'mobile',1,1),(5,4,'identity',1,1),(6,4,'gender',1,1),(7,4,'district',1,1),(8,4,'consent',1,1),(9,4,'age',1,1),(10,4,'aadhaar_last4',1,1),(11,13,'state',1,1),(12,13,'qrc',1,1),(13,13,'name',1,1),(14,13,'mobile',1,1),(15,13,'identity',1,1),(16,13,'gender',1,1),(17,13,'district',1,1),(18,13,'consent',1,1),(19,13,'age',1,1),(20,13,'aadhaar_last4',1,1),(21,8,'state',1,1),(22,8,'qrc',1,1),(23,8,'name',1,1),(24,8,'mobile',1,1),(25,8,'identity',1,1),(26,8,'gender',1,1),(27,8,'district',1,1),(28,8,'consent',1,1),(29,8,'age',1,1),(30,8,'aadhaar_last4',1,1),(31,10,'state',1,1),(32,10,'qrc',1,1),(33,10,'name',1,1),(34,10,'mobile',1,1),(35,10,'identity',1,1),(36,10,'gender',1,1),(37,10,'district',1,1),(38,10,'consent',1,1),(39,10,'age',1,1),(40,10,'aadhaar_last4',1,1),(41,6,'state',1,1),(42,6,'qrc',1,1),(43,6,'name',1,1),(44,6,'mobile',1,1),(45,6,'identity',1,1),(46,6,'gender',1,1),(47,6,'district',1,1),(48,6,'consent',1,1),(49,6,'age',1,1),(50,6,'aadhaar_last4',1,1),(51,5,'state',1,1),(52,5,'qrc',1,1),(53,5,'name',1,1),(54,5,'mobile',1,1),(55,5,'identity',1,1),(56,5,'gender',1,1),(57,5,'district',1,1),(58,5,'consent',1,1),(59,5,'age',1,1),(60,5,'aadhaar_last4',1,1),(61,1,'state',1,1),(62,1,'qrc',1,1),(63,1,'name',1,1),(64,1,'mobile',1,1),(65,1,'identity',1,1),(66,1,'gender',1,1),(67,1,'district',1,1),(68,1,'consent',1,1),(69,1,'age',1,1),(70,1,'aadhaar_last4',1,1),(71,7,'state',1,1),(72,7,'qrc',1,1),(73,7,'name',1,1),(74,7,'mobile',1,1),(75,7,'identity',1,1),(76,7,'gender',1,1),(77,7,'district',1,1),(78,7,'consent',1,1),(79,7,'age',1,1),(80,7,'aadhaar_last4',1,1),(81,11,'state',1,1),(82,11,'qrc',1,1),(83,11,'name',1,1),(84,11,'mobile',1,1),(85,11,'identity',1,1),(86,11,'gender',1,1),(87,11,'district',1,1),(88,11,'consent',1,1),(89,11,'age',1,1),(90,11,'aadhaar_last4',1,1),(91,3,'state',1,1),(92,3,'qrc',1,1),(93,3,'name',1,1),(94,3,'mobile',1,1),(95,3,'identity',1,1),(96,3,'gender',1,1),(97,3,'district',1,1),(98,3,'consent',1,1),(99,3,'age',1,1),(100,3,'aadhaar_last4',1,1),(101,9,'state',1,1),(102,9,'qrc',1,1),(103,9,'name',1,1),(104,9,'mobile',1,1),(105,9,'identity',1,1),(106,9,'gender',1,1),(107,9,'district',1,1),(108,9,'consent',1,1),(109,9,'age',1,1),(110,9,'aadhaar_last4',1,1),(111,12,'state',1,1),(112,12,'qrc',1,1),(113,12,'name',1,1),(114,12,'mobile',1,1),(115,12,'identity',1,1),(116,12,'gender',1,1),(117,12,'district',1,1),(118,12,'consent',1,1),(119,12,'age',1,1),(120,12,'aadhaar_last4',1,1),(121,2,'state',1,1),(122,2,'qrc',1,1),(123,2,'name',1,1),(124,2,'mobile',1,1),(125,2,'identity',1,1),(126,2,'gender',1,1),(127,2,'district',1,1),(128,2,'consent',1,1),(129,2,'age',1,1),(130,2,'aadhaar_last4',1,1),(131,14,'state',1,1),(132,14,'qrc',1,1),(133,14,'name',1,1),(134,14,'mobile',1,1),(135,14,'identity',1,1),(136,14,'gender',1,1),(137,14,'district',1,1),(138,14,'consent',1,1),(139,14,'age',1,1),(140,14,'aadhaar_last4',1,1);
/*!40000 ALTER TABLE `service_form_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_types`
--

DROP TABLE IF EXISTS `service_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `english_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hindi_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requires_eid` tinyint(1) DEFAULT '0',
  `requires_sid` tinyint(1) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `display_order` int DEFAULT '0',
  `requires_identity` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `english_name` (`english_name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_types`
--

LOCK TABLES `service_types` WRITE;
/*!40000 ALTER TABLE `service_types` DISABLE KEYS */;
INSERT INTO `service_types` VALUES (1,'DOB CHANGE','जन्म तिथि परिवर्तन',0,0,1,1,1),(2,'NAME CHANGE','नाम परिवर्तन',0,0,1,2,1),(3,'GENDER CHANGE','लिंग परिवर्तन',0,0,1,3,1),(4,'AADHAAR LOCK','आधार लॉक',0,0,1,4,1),(5,'DELAY IN AADHAAR UPDATE','आधार अपडेट में विलंब',0,0,1,5,1),(6,'DEACTIVATED AADHAAR','निष्क्रिय आधार',0,0,1,6,1),(7,'DUAL AADHAAR','दोहरा आधार',0,0,1,7,1),(8,'BIOMETRIC ISSUES','बायोमेट्रिक समस्या',0,0,1,8,1),(9,'HOME ENROLMENT','घर पर नामांकन',0,0,1,9,1),(10,'CANCELLED AADHAAR','रद्द किया गया आधार',0,0,1,10,1),(11,'ENROLMENT REJECTED DUE TO DUPLICATE','डुप्लिकेट के कारण नामांकन अस्वीकृत',0,0,1,11,1),(12,'LOST AADHAAR','खोया हुआ आधार',0,0,1,12,1),(13,'AADHAAR NOT GENERATED','आधार जनरेट नहीं हुआ',0,0,1,13,1),(14,'OTHERS (SPECIFY)','अन्य (निर्दिष्ट करें)',0,0,1,14,1);
/*!40000 ALTER TABLE `service_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aadhaar_last4` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int DEFAULT NULL,
  `gender` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `divyang` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qrc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `mode` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `device_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visited` tinyint(1) DEFAULT '0',
  `visited_at` datetime DEFAULT NULL,
  `distance_meters` int DEFAULT NULL,
  `token_seq` int DEFAULT NULL,
  `entry_marked` tinyint(1) DEFAULT '0',
  `entry_time` datetime DEFAULT NULL,
  `eid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identity_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hardware_fp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_other` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_token_seq_per_day` (`date`,`token_seq`),
  KEY `idx_tokens_date` (`date`),
  KEY `idx_tokens_visited` (`visited`),
  KEY `idx_tokens_service` (`service_type`),
  KEY `idx_tokens_mode` (`mode`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (1,'001-AN-1223','Shreeya Pandey','8707027953','1223',21,'Female',NULL,'Jhajjar','NAME CHANGE','','2026-09-28','A','N','2026-09-26 10:50:11','DEV-2fb8c426-750e-4177-b0bf-2efd72d1f44d','AN',0,NULL,600112,1,0,NULL,NULL,'SID','S182819218292288191928291291','HW-417c8e2419c166398c6b6f78de7bea8858205cceaf63bfe700cfc0be2706d978','Haryana',NULL);
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recovery_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'operator','$2b$10$2tzpY5ulz07/8I.Tb2My7eB8l24ofcp5Xh7sb4JfJJYD0ykM8nwW6','SERVICE_COUNTER','GUARD2_SESSION','guard2.html',NULL,1),(2,'admin','$2b$10$34ZWE0St6C5XG32O/uLdi.J5kShgbCVOkzkNUUfz.ULImNXkTNXTO','MANAGER','MANAGER_SESSION','manager.html','LkoTS#110726',1),(3,'guard','$2b$10$3LsyOGogsy.jQBwCKZAIDeP7QlYik648J8ByykT5BvDyl4WP3E4cy','GUARD','GUARD_SESSION','guard.html',NULL,1),(4,'guard3','$2b$10$38dzSC/4tTuYn64.qY3EXOa0oVpFXtiQFvuW9O2yzs0rk3CKZGARq','GUARD3','GUARD3_SESSION','guard3.html',NULL,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weekday_slot_rules`
--

DROP TABLE IF EXISTS `weekday_slot_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weekday_slot_rules` (
  `weekday` int NOT NULL,
  `weekday_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `appointment_total` int NOT NULL,
  `walkin_total` int NOT NULL,
  `tokens_per_hour` int DEFAULT '30',
  `work_start_time` time DEFAULT NULL,
  PRIMARY KEY (`weekday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekday_slot_rules`
--

LOCK TABLES `weekday_slot_rules` WRITE;
/*!40000 ALTER TABLE `weekday_slot_rules` DISABLE KEYS */;
INSERT INTO `weekday_slot_rules` VALUES (0,'Sunday',0,0,30,'09:30:00'),(1,'Monday',210,90,30,'09:30:00'),(2,'Tuesday',210,90,30,'09:30:00'),(3,'Wednesday',210,90,30,'09:30:00'),(4,'Thursday',210,90,30,'09:30:00'),(5,'Friday',210,90,30,'09:30:00'),(6,'Saturday',0,0,30,'09:30:00'),(7,'Sunday',0,0,30,'09:30:00');
/*!40000 ALTER TABLE `weekday_slot_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_days`
--

DROP TABLE IF EXISTS `working_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_days` (
  `date` date NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_days`
--

LOCK TABLES `working_days` WRITE;
/*!40000 ALTER TABLE `working_days` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_days` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-26  9:47:24
