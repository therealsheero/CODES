const router = require("express").Router();

const settingsController =
require("../controllers/settings.controller");

router.get(
    "/",
    settingsController.getPublicSettings
);

router.get(
    "/service-types",
    settingsController.getServiceTypes
);

router.get(
    "/service-form-settings/:id",
    settingsController.getServiceFormSettings
);

router.get(
    "/district-master",
    settingsController.getDistricts
);

router.get(
    "/priority-settings",
    settingsController.getPrioritySettings
);

router.get(
    "/is-working-day",
    settingsController.isWorkingDay
);

router.get(
    "/tokens-per-hour",
    settingsController.getTokensPerHourPublic
);

router.get(
    "/work-start-time",
    settingsController.getWorkStartTime
);

router.get(
    "/qr-settings",
    settingsController.getQRSettings
);

router.get(
    "/today-notice",
    settingsController.getTodayNotice
);

module.exports = router;
