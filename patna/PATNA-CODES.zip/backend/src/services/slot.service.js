const db = require("../models/db");

const {
  getWeekdaySlots
} = require("../utils/weekdaySlots");

let mutationQueue = Promise.resolve();

function withSlotMutationLock(task) {
  const next = mutationQueue.then(task, task);
  mutationQueue = next.catch(() => {});
  return next;
}

async function ensureDayRow(date, connection = db) {
  const slots = await getWeekdaySlots(date);

  await connection.execute(
    `
    INSERT IGNORE INTO daily_slots
    (
      date,
      appointment_total,
      appointment_booked,
      walkin_total,
      walkin_booked
    )
    VALUES (?, ?, 0, ?, 0)
    `,
    [
      date,
      slots.appointment,
      slots.walkin
    ]
  );
}

async function reserveSlot(date, mode, connection = db) {
  await ensureDayRow(date, connection);

  const bookedCol =
    mode === "A" ? "appointment_booked" : "walkin_booked";

  const totalCol =
    mode === "A" ? "appointment_total" : "walkin_total";

  const sql = `
    UPDATE daily_slots
    SET ${bookedCol} = ${bookedCol} + 1
    WHERE date = ?
    AND ${bookedCol} < ${totalCol}
  `;

  const [result] = await connection.execute(sql, [date]);

  if (result.affectedRows === 0) {
    throw new Error("No slots available");
  }
}

module.exports = {
  reserveSlot,
  withSlotMutationLock
};