const db = require("../models/db");

const bcrypt = require("bcrypt");

const {
    getISTDateString,
    getISTDateTimeString,
    getISTHour
} = require("../utils/date.utils");


exports.guardLogin = async (req, res) => {
    const {
        username,
        password
    } = req.body;

    try {
        const [rows] = await db.execute(
            `
            SELECT *
            FROM users
            WHERE username = ?
            `,
            [username]
        );

        const user = rows[0];

        if (!user) {
            return res.status(401).json({
                message: "Invalid credentials"
            });
        }

        if (user.is_active === 0) {
            return res.status(403).json({
                message: "Account disabled. Contact manager."
            });
        }

        const ok = await bcrypt.compare(
            password,
            user.password
        );

        if (!ok) {
            return res.status(401).json({
                message: "Invalid credentials"
            });
        }

        res.json({
            success: true,
            token: user.session_name,
            page: user.page
        });

    } catch (err) {
        console.error("[guardLogin] DB error:", err.message);

        return res.status(500).json({
            message: "DB error"
        });
    }
};


exports.addPhysicalReferenceEntry = async (req, res) => {

    const {
        name,
        age,
        mobile,
        aadhaar_last4,
        gender,
        district,
        service_type,
        reference_of,
        token_type,
        eid
    } = req.body;

    try {

        const today = getISTDateString();

        const [rows] = await db.execute(
            `
            SELECT COUNT(*) AS count
            FROM physical_reference_entries
            WHERE DATE(created_at) = ?
            `,
            [today]
        );

        const nextSeq = Number(rows[0].count) + 1;

        const seq = String(nextSeq).padStart(3, "0");

        let typeCode = "PT";

        if (token_type === "Reference") {
            typeCode = "RT";
        } else if (token_type === "Specially Abled") {
            typeCode = "PwD";
        }

        const token = `${seq}-${typeCode}-${aadhaar_last4}`;

        await db.execute(
            `
            INSERT INTO physical_reference_entries (
                token,
                name,
                age,
                mobile,
                aadhaar_last4,
                gender,
                district,
                service_type,
                reference_of,
                token_type,
                eid
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `,
            [
                token,
                name,
                age,
                mobile,
                aadhaar_last4,
                gender,
                district,
                service_type,
                reference_of,
                token_type,
                eid || null
            ]
        );

        res.json({
            success: true,
            token
        });

    } catch (err) {
        console.error(
            "[addPhysicalReferenceEntry] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "DB error"
        });
    }
};


exports.getTodayPhysicalReferenceEntries = async (req, res) => {

    try {

        const today = getISTDateString();

        const [rows] = await db.execute(
            `
            SELECT *
            FROM physical_reference_entries
            WHERE DATE(created_at) = ?
            `,
            [today]
        );

        res.json(rows);

    } catch (err) {
        console.error(
            "[getTodayPhysicalReferenceEntries] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "DB error"
        });
    }
};


async function getDefaultTokensPerHour() {

    const [rows] = await db.execute(
        `
        SELECT rule_value
        FROM priority_rules
        WHERE rule_key = 'default_tokens_per_hour'
        `
    );

    return Number(rows[0]?.rule_value || 30);
}


exports.getTokensPerHourToday = async (req, res) => {

    try {

        const today = getISTDateString();

        const [rows] = await db.execute(
            `
            SELECT tokens_per_hour
            FROM daily_token_counters
            WHERE date = ?
            `,
            [today]
        );

        const row = rows[0];

        const defaultTokens =
            await getDefaultTokensPerHour();

        res.json({
            tokensPerHour:
                row?.tokens_per_hour ??
                defaultTokens
        });

    } catch (err) {
        console.error(
            "[getTokensPerHourToday] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "DB error"
        });
    }
};


exports.getTokensPerHourToday2 = async (req, res) => {

    try {

        const today = getISTDateString();

        const [rows] = await db.execute(
            `
            SELECT tokens_per_hour
            FROM daily_token_counters
            WHERE date = ?
            `,
            [today]
        );

        const row = rows[0];

        const defaultTokens =
            await getDefaultTokensPerHour();

        res.json({
            tokensPerHour:
                row?.tokens_per_hour ??
                defaultTokens
        });

    } catch (err) {
        console.error(
            "[getTokensPerHourToday2] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "DB error"
        });
    }
};


exports.getTodayTokens = async (req, res) => {

    try {

        const today = getISTDateString();

        const [rows] = await db.execute(
            `
            SELECT *
            FROM tokens
            WHERE date = ?
            AND (
                visited = 0
                OR (
                    visited = 1
                    AND visited_at >= NOW() - INTERVAL 10 MINUTE
                )
            )
            ORDER BY created_at ASC
            `,
            [today]
        );

        res.json(rows);

    } catch (err) {
        console.error(
            "[getTodayTokens] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "DB error"
        });
    }
};


exports.undoEntry = async (req, res) => {

    const { token_id } = req.body;

    try {

        const [result] = await db.execute(
            `
            UPDATE tokens
            SET entry_marked = 0,
                entry_time = NULL
            WHERE id = ?
              AND entry_marked = 1
              AND entry_time >= NOW() - INTERVAL 10 MINUTE
            `,
            [token_id]
        );

        if (result.affectedRows === 0) {
            return res.status(403).json({
                message: "Undo window expired"
            });
        }

        res.json({
            success: true
        });

    } catch (err) {
        console.error(
            "[undoEntry] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "DB error"
        });
    }
};


exports.markEntry = async (req, res) => {

    const { token_id } = req.body;

    try {

        await db.execute(
            `
            UPDATE tokens
            SET entry_marked = 1,
                entry_time = NOW()
            WHERE id = ?
            `,
            [token_id]
        );

        res.json({
            success: true
        });

    } catch (err) {
        console.error(
            "[markEntry] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "DB error"
        });
    }
};


exports.getEntryTokens = async (req, res) => {

    try {

        const today = getISTDateString();

        const [rows] = await db.execute(
            `
            SELECT *
            FROM tokens
            WHERE date = ?
            AND (
                entry_marked = 0
                OR (
                    entry_marked = 1
                    AND entry_time >= NOW() - INTERVAL 10 MINUTE
                )
            )
            ORDER BY created_at ASC
            `,
            [today]
        );

        res.json(rows);

    } catch (err) {
        console.error(
            "[getEntryTokens] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "DB error"
        });
    }
};


exports.getServiceTokens = async (req, res) => {

    try {

        const today = getISTDateString();

        const [rows] = await db.execute(
            `
            SELECT *
            FROM tokens
            WHERE date = ?
            AND entry_marked = 1
            AND (
                visited = 0
                OR (
                    visited = 1
                    AND visited_at >= NOW() - INTERVAL 10 MINUTE
                )
            )
            ORDER BY created_at ASC
            `,
            [today]
        );

        res.json(rows);

    } catch (err) {
        console.error(
            "[getServiceTokens] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "DB error"
        });
    }
};


exports.markVisited = async (req, res) => {

    const { token_id } = req.body;

    try {

        await db.execute(
            `
            UPDATE tokens
            SET visited = 1,
                visited_at = NOW()
            WHERE id = ?
            `,
            [token_id]
        );

        res.json({
            success: true
        });

    } catch (err) {
        console.error(
            "[markVisited] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "DB error"
        });
    }
};


exports.undoVisited = async (req, res) => {

    const { token_id } = req.body;

    try {

        const [result] = await db.execute(
            `
            UPDATE tokens
            SET visited = 0,
                visited_at = NULL
            WHERE id = ?
              AND visited = 1
              AND visited_at >= NOW() - INTERVAL 10 MINUTE
            `,
            [token_id]
        );

        if (result.affectedRows === 0) {
            return res.status(403).json({
                message: "Undo window expired"
            });
        }

        res.json({
            success: true
        });

    } catch (err) {
        console.error(
            "[undoVisited] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "DB error"
        });
    }
};