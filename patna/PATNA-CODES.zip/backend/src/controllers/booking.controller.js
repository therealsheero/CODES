const db = require("../models/db");

const {
  reserveSlot,
  withSlotMutationLock
} = require("../services/slot.service");

const { generateDailyToken } = require("../services/token.service");

const {
  getISTDateString,
  getISTHour
} = require("../utils/date.utils");


function normalizeDistrict(d) {
  return d.split("/")[0].trim();
}


function timeToMinutes(time) {
  const [hour, minute] = time.split(":").map(Number);
  return hour * 60 + minute;
}


async function getBookingSettings(connection = db) {
  const [rows] = await connection.execute(
    `
    SELECT rule_key, rule_value
    FROM priority_rules
    `
  );

  const settings = {};

  rows.forEach(r => {
    settings[r.rule_key] = r.rule_value;
  });

  return settings;
}


exports.retrieveToken = async (req, res) => {
  const {
    mobile,
    aadhaar_last4,
    date
  } = req.body;

  if (!mobile || !aadhaar_last4 || !date) {
    return res.status(400).json({
      message: "Mobile, Aadhaar last 4 digits and date required"
    });
  }

  try {
    const [rows] = await db.execute(
      `
      SELECT
        token,
        name,
        mobile,
        aadhaar_last4,
        service_type,
        date,
        mode,
        priority,
        token_type
      FROM tokens
      WHERE mobile = ?
      AND aadhaar_last4 = ?
      AND date = ?
      LIMIT 1
      `,
      [
        mobile,
        aadhaar_last4,
        date
      ]
    );

    const row = rows[0];

    if (!row) {
      return res.status(404).json({
        message: "No token found"
      });
    }

    res.json({
      success: true,
      token: row
    });

  } catch (err) {
    console.error("[retrieveToken] Database error:", err.message);

    return res.status(500).json({
      message: "Database error"
    });
  }
};


async function getFormSettings(connection = db) {
  const [rows] = await connection.execute(
    `
    SELECT *
    FROM form_settings
    `
  );

  const settings = {};

  rows.forEach(r => {
    settings[r.field_key] = r;
  });

  return settings;
}


async function getService(service, connection = db) {
  const [rows] = await connection.execute(
    `
    SELECT *
    FROM service_types
    WHERE english_name = ?
    `,
    [service]
  );

  return rows[0] || null;
}


async function getServiceType(service, connection = db) {
  const [rows] = await connection.execute(
    `
    SELECT *
    FROM service_types
    WHERE english_name = ?
    AND active = 1
    `,
    [service]
  );

  return rows[0] || null;
}


async function isWeekend(dateStr, connection = db) {
  const d = new Date(dateStr);
  const day = d.getDay();

  if (day !== 0 && day !== 6) {
    return false;
  }

  const [rows] = await connection.execute(
    `
    SELECT 1
    FROM working_days
    WHERE date = ?
    `,
    [dateStr]
  );

  return !rows[0];
}


async function getServiceFormSettings(serviceId, connection = db) {
  const [rows] = await connection.execute(
    `
    SELECT
      field_key,
      enabled,
      mandatory
    FROM service_form_settings
    WHERE service_type_id = ?
    ORDER BY field_key
    `,
    [serviceId]
  );

  const settings = {};

  rows.forEach(r => {
    settings[r.field_key] = {
      enabled: r.enabled,
      mandatory: r.mandatory
    };
  });

  return settings;
}


async function isGazettedHoliday(dateStr, connection = db) {
  const [rows] = await connection.execute(
    `
    SELECT 1
    FROM holidays
    WHERE date = ?
    `,
    [dateStr]
  );

  return !!rows[0];
}


function generateEID(
  enrollmentNo,
  eidDate,
  eidTime
) {
  const enroll = enrollmentNo.replace(/\D/g, "");

  const [year, month, day] = eidDate.split("-");

  const datePart = `${year}${month}${day}`;

  const timePart = eidTime.replace(/:/g, "");

  return enroll + datePart + timePart;
}


async function generateToken(req, res) {

  const {
    device_id,
    hardware_fp,
    name,
    mobile,
    aadhaar_last4,
    age,
    gender,
    divyang=null,
    district,
    service_type,
    qrc,
    mode,
    selected_date,
    enrollment_no,
    eid_date,
    eid_time,
    identity_type=null,
    sid,
    service_other
  } = req.body;


  const service = await getServiceType(service_type);

  if (!service) {
    return res.status(400).json({
      message: "Invalid service type"
    });
  }


  const formSettings = await getServiceFormSettings(service.id);


  function isFieldEnabled(key) {
    return (
      formSettings[key] &&
      formSettings[key].enabled === 1
    );
  }


  const fieldValues = {
    qrc,
    name,
    mobile,
    aadhaar_last4,
    gender,
    age,
    district,

    identity:
      formSettings.identity &&
      formSettings.identity.enabled === 1 &&
      formSettings.identity.mandatory === 1
        ? identity_type
        : "NOT_REQUIRED",

    consent: true
  };


  for (const key in formSettings) {

    const setting = formSettings[key];

    if (
      setting.enabled === 1 &&
      setting.mandatory === 1
    ) {

      if (
        fieldValues[key] === undefined ||
        fieldValues[key] === null ||
        fieldValues[key] === ""
      ) {

        return res.status(400).json({
          message: `${key} is required`
        });

      }
    }
  }


  const mobileRegex = /^[6-9][0-9]{9}$/;

  if (
    isFieldEnabled("mobile") &&
    mobile &&
    !mobileRegex.test(mobile)
  ) {
    return res.status(400).json({
      message: "Invalid mobile number. Must start with 6,7,8,9"
    });
  }


  const nameRegex = /^[A-Za-z\s]{2,50}$/;

  if (
    isFieldEnabled("name") &&
    name &&
    !nameRegex.test(name)
  ) {
    return res.status(400).json({
      message: "Invalid name. Only alphabets allowed."
    });
  }


  let eid = null;
  let sidValue = null;


  if (isFieldEnabled("identity")) {

    if (!identity_type) {
      return res.status(400).json({
        message: "Select EID or SID"
      });
    }


    if (identity_type === "EID") {

      if (!enrollment_no || !eid_date || !eid_time) {
        return res.status(400).json({
          message: "EID details are required"
        });
      }


      const enrollDigits =
        enrollment_no.replace(/\D/g, "");


      if (enrollDigits.length !== 14) {
        return res.status(400).json({
          message: "Enrollment number must contain 14 digits"
        });
      }


      eid = generateEID(
        enrollment_no,
        eid_date,
        eid_time
      );

    } else if (identity_type === "SID") {

      if (!sid) {
        return res.status(400).json({
          message: "SID is required"
        });
      }


      const cleanSID = sid.trim();

      const sidRegex = /^S\d{27}$/;

      if (!sidRegex.test(cleanSID)) {
        return res.status(400).json({
          message:
            "Invalid SID format. SID must start with S and contain 27 digits."
        });
      }

      sidValue = cleanSID;
    }
  }


  const qrcRegex = /^S[A-Za-z0-9]+000$/;

  if (
    isFieldEnabled("qrc") &&
    qrc &&
    !qrcRegex.test(qrc)
  ) {
    return res.status(400).json({
      message:
        "Invalid QRC format. Must start with S and end with 000."
    });
  }


  let connection = null;
  let transactionStarted = false;

  try {

    /*
     * Get ONE MySQL connection for the complete booking transaction.
     */
    connection = await db.getConnection();

    await connection.beginTransaction();

    transactionStarted = true;


    /*
     * QRC validation
     */
    if (isFieldEnabled("qrc")) {

      const [qrcRows] = await connection.execute(
        `
        SELECT id
        FROM tokens
        WHERE qrc = ?
        LIMIT 1
        `,
        [qrc]
      );

      const qrcExists = !!qrcRows[0];

      if (qrcExists) {
        throw new Error("This QRC has already been used");
      }


      const [qrcCountRows] = await connection.execute(
        `
        SELECT COUNT(DISTINCT qrc) AS count
        FROM tokens
        WHERE mobile = ?
        `,
        [mobile]
      );

      const qrcCountForMobile =
        Number(qrcCountRows[0].count);


      if (qrcCountForMobile >= 2) {
        throw new Error(
          "Only 2 QRCs allowed per mobile number."
        );
      }
    }


    /*
     * Maximum tokens per mobile
     */
    const [tokenCountRows] = await connection.execute(
      `
      SELECT COUNT(*) AS count
      FROM tokens
      WHERE mobile = ?
      `,
      [mobile]
    );

    const tokenCount =
      Number(tokenCountRows[0].count);


    if (tokenCount >= 3) {
      throw new Error(
        "Maximum 3 tokens allowed per mobile number"
      );
    }


    let bookingDate;


    /*
     * Walk-in / appointment date handling
     */
    if (mode === "W") {

      const bookingSettings =
        await getBookingSettings(connection);

      const walkinStartTime =
        bookingSettings.walkin_start_hour;

      const walkinEndTime =
        bookingSettings.walkin_end_hour;


      if (!walkinStartTime || !walkinEndTime) {
        throw new Error(
          "Walk-in timing is not configured"
        );
      }


      const currentMinutes = (() => {

        const parts =
          new Intl.DateTimeFormat("en-GB", {
            timeZone: "Asia/Kolkata",
            hour: "2-digit",
            minute: "2-digit",
            hour12: false
          }).formatToParts(new Date());

        const h =
          Number(
            parts.find(p => p.type === "hour").value
          );

        const m =
          Number(
            parts.find(p => p.type === "minute").value
          );

        return h * 60 + m;

      })();


      const startMinutes =
        timeToMinutes(walkinStartTime);

      const endMinutes =
        timeToMinutes(walkinEndTime);


      if (currentMinutes < startMinutes) {
        throw new Error(
          `Walk-in booking starts at ${walkinStartTime}`
        );
      }


      if (currentMinutes >= endMinutes) {
        throw new Error(
          `Walk-in booking closed at ${walkinEndTime}`
        );
      }


      bookingDate = getISTDateString();


      const isWeekendDay =
        await isWeekend(
          bookingDate,
          connection
        );

      const isHoliday =
        await isGazettedHoliday(
          bookingDate,
          connection
        );


      if (isWeekendDay || isHoliday) {
        throw new Error(
          "Walk-in tokens cannot be generated on holidays"
        );
      }


      if (selected_date) {
        throw new Error(
          "Walk-in cannot have appointment date"
        );
      }

    } else {

      if (!selected_date) {
        throw new Error(
          "Appointment date is required"
        );
      }


      const dateRegex =
        /^\d{4}-\d{2}-\d{2}$/;


      if (!dateRegex.test(selected_date)) {
        throw new Error(
          "Invalid appointment date"
        );
      }


      bookingDate = selected_date;
    }


    /*
     * One token per device per day
     */
    const [deviceRows] = await connection.execute(
      `
      SELECT id
      FROM tokens
      WHERE device_id = ?
      AND date = ?
      LIMIT 1
      `,
      [
        device_id,
        bookingDate
      ]
    );


    const deviceTokenExists =
      !!deviceRows[0];


    if (deviceTokenExists) {
      throw new Error(
        "Only one token per device is allowed per day"
      );
    }


    /*
     * Reserve the slot using THE SAME transaction connection.
     */
    await reserveSlot(
      bookingDate,
      mode,
      connection
    );


    /*
     * Determine long-distance district.
     */
    const cleanDistrict =
      normalizeDistrict(district);


    const [districtRows] =
      await connection.execute(
        `
        SELECT district
        FROM priority_districts
        `
      );


    const longDistance =
      districtRows.map(d => d.district);


    const isLongDistance =
      longDistance.includes(cleanDistrict);


    /*
     * Load priority rules.
     */
    const [rules] =
      await connection.execute(
        `
        SELECT *
        FROM priority_rules
        `
      );


    const ruleMap = {};

    rules.forEach(r => {
      ruleMap[r.rule_key] = r.rule_value;
    });


    const childAge =
      Number(ruleMap.child_age_limit);

    const seniorAge =
      Number(ruleMap.senior_age_limit);

    const femaleAge =
      Number(ruleMap.female_priority_age);


    let tokenType;


    /*
     * Appointment token type
     */
    if (mode === "A") {

      const todayIST =
        getISTDateString();

      const currentHour =
        getISTHour();

      const isToday =
        bookingDate === todayIST;

      const before10 =
        currentHour < 6;


      if (
        age <= childAge ||
        age >= seniorAge
      ) {
        tokenType = "AP";

      } else if (
        gender === "Female" &&
        age >= femaleAge
      ) {
        tokenType = "AP";

      } else if (
        isToday &&
        before10 &&
        isLongDistance
      ) {
        tokenType = "AL";

      } else {
        tokenType = "AN";
      }


    } else {

      /*
       * Walk-in token type
       */
      if (
        age <= childAge ||
        age >= seniorAge
      ) {
        tokenType = "WP";

      } else if (
        gender === "Female" &&
        age >= femaleAge
      ) {
        tokenType = "WP";

      } else if (isLongDistance) {
        tokenType = "WL";

      } else {
        tokenType = "WN";
      }
    }


    /*
     * Generate the daily token using THE SAME
     * MySQL transaction connection.
     */
    const {
      token,
      token_seq,
      priority
    } = await generateDailyToken(
      name,
      mobile,
      aadhaar_last4,
      bookingDate,
      age,
      gender,
      divyang,
      mode,
      tokenType,
      connection
    );


    /*
     * Insert token.
     */
const insertParams = [
  token,
  token_seq,
  name,
  mobile,
  aadhaar_last4,
  age,
  gender,
  divyang,
  cleanDistrict,
  service_type,
  qrc,
  bookingDate,
  mode,
  priority,
  device_id,
  hardware_fp,
  tokenType,
  req.body.distance_meters || 0,
  eid,
  identity_type,
  sidValue,
  service_other
];

const paramNames = [
  "token",
  "token_seq",
  "name",
  "mobile",
  "aadhaar_last4",
  "age",
  "gender",
  "divyang",
  "district",
  "service_type",
  "qrc",
  "date",
  "mode",
  "priority",
  "device_id",
  "hardware_fp",
  "token_type",
  "distance_meters",
  "eid",
  "identity_type",
  "sid",
  "service_other"
];

const undefinedParams = insertParams
  .map((value, index) => value === undefined ? paramNames[index] : null)
  .filter(Boolean);

if (undefinedParams.length > 0) {
  console.error(
    "[generateToken] UNDEFINED INSERT PARAMS:",
    undefinedParams
  );
}
    await connection.execute(
      `
      INSERT INTO tokens
      (
        token,
        token_seq,
        name,
        mobile,
        aadhaar_last4,
        age,
        gender,
        divyang,
        district,
        service_type,
        qrc,
        date,
        mode,
        priority,
        device_id,
        hardware_fp,
        token_type,
        distance_meters,
        eid,
        identity_type,
        sid,
        service_other
      )
      VALUES
      (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
      )
      `,
      [
        token,
        token_seq,
        name,
        mobile,
        aadhaar_last4,
        age,
        gender,
        divyang,
        cleanDistrict,
        service_type,
        qrc,
        bookingDate,
        mode,
        priority,
        device_id,
        hardware_fp,
        tokenType,
        req.body.distance_meters || 0,
        eid,
        identity_type,
        sidValue,
        service_other
      ]
    );


    /*
     * Everything succeeded.
     */
    await connection.commit();

    transactionStarted = false;


    res.status(201).json({
      message: "Token generated successfully",
      token,
      date: bookingDate,
      mode,
      priority
    });


  } catch (err) {

    if (connection && transactionStarted) {

      try {
        await connection.rollback();
      } catch (rollbackErr) {
        console.error(
          "[generateToken] Rollback failed:",
          rollbackErr.message
        );
      }
    }


    console.error(
      "[generateToken] Error:",
      err.message
    );


    res.status(400).json({
      message: err.message
    });


  } finally {

    if (connection) {
      connection.release();
    }

  }
}


exports.generateToken = (req, res) =>
  withSlotMutationLock(
    () => generateToken(req, res)
  );