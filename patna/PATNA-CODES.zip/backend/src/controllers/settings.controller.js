const db = require("../models/db");

exports.getPublicSettings = async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT
        rule_key,
        rule_value
      FROM priority_rules
      WHERE rule_key IN (
        'appointment_days_visible',
        'walkin_start_hour',
        'walkin_end_hour',
        'today_appointment_cutoff_hour',
        'geo_start_1',
        'geo_end_1',
        'geo_start_2',
        'geo_end_2',
        'geofence_distance_meters',
        'office_open_saturday',
        'office_open_sunday',
        'default_tokens_per_hour',
        'office_display_en',
        'office_display_hi',
        'office_short_name',
        'watermark_text',
        'gazette_office_address'
      )
    `);

    res.json(rows);

  } catch (err) {
    console.error(
      "[settings] Error:",
      err.message
    );

    res.status(500).json({
      message: "DB error"
    });
  }
};

const managerController =
  require("./manager.controller");

const qrController =
  require("./qr.controller");

exports.getServiceTypes =
  managerController.getServiceTypes;

exports.getServiceFormSettings =
  managerController.getServiceFormSettings;

exports.getDistricts =
  managerController.getDistricts;

exports.getPrioritySettings =
  managerController.getPrioritySettings;

exports.isWorkingDay =
  managerController.isWorkingDay;

exports.getTokensPerHourPublic =
  managerController.getTokensPerHourPublic;

exports.getWorkStartTime =
  managerController.getWorkStartTime;

exports.getTodayNotice =
  managerController.getTodayNotice;

exports.getQRSettings =
  qrController.getQRSettings;