const db = require("../models/db");

exports.uploadQR = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        message: "No QR uploaded"
      });
    }

    const type = req.params.type;

    const fileName = req.file.filename;

    const filePath =
      "assets/QRs/" + fileName;

    await db.execute(
      `
      UPDATE qr_settings
      SET
        file_name = ?,
        file_path = ?,
        is_active = 1,
        updated_at = NOW()
      WHERE qr_type = ?
      `,
      [
        fileName,
        filePath,
        type
      ]
    );

    res.json({
      success: true,
      message: "QR updated successfully"
    });

  } catch (err) {
    console.error(
      "[QR upload] Error:",
      err.message
    );

    res.status(500).json({
      message: "DB error"
    });
  }
};


exports.getQRSettings = async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT *
      FROM qr_settings
    `);

    res.json(rows);

  } catch (err) {
    console.error(
      "[QR settings] Error:",
      err.message
    );

    res.status(500).json({
      message: "DB error"
    });
  }
};


exports.deleteQR = async (req, res) => {
  try {
    const type = req.params.type;

    await db.execute(
      `
      UPDATE qr_settings
      SET
        file_path = NULL,
        file_name = NULL,
        is_active = 0,
        updated_at = NOW()
      WHERE qr_type = ?
      `,
      [type]
    );

    res.json({
      success: true
    });

  } catch (err) {
    console.error(
      "[QR delete] Error:",
      err.message
    );

    res.status(500).json({
      message: "DB error"
    });
  }
};