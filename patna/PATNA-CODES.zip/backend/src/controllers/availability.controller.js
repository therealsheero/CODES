const db = require("../models/db");

const {
  getISTDateString,
  getISTHour
} = require("../utils/date.utils");

const {
  getWeekdaySlots
} = require("../utils/weekdaySlots");


async function getPrioritySettings() {
  const [rows] = await db.execute(`
    SELECT rule_key, rule_value
    FROM priority_rules
  `);

  const rules = {};

  rows.forEach((r) => {
    rules[r.rule_key] = r.rule_value;
  });

  return rules;
}


async function ensureDateRange(startDate, days) {
  for (let i = 0; i < days; i++) {
    const d = new Date(startDate);

    d.setDate(
      d.getDate() + i
    );

    const dateStr = d.toLocaleDateString(
      "en-CA",
      {
        timeZone: "Asia/Kolkata"
      }
    );

    const slots = await getWeekdaySlots(dateStr);

    await db.execute(
      `
      INSERT IGNORE INTO daily_slots
      (
        date,
        appointment_total,
        appointment_booked,
        walkin_total,
        walkin_booked
      )
      VALUES (?, ?, 0, ?, 0)
      `,
      [
        dateStr,
        slots.appointment,
        slots.walkin
      ]
    );
  }
}


exports.getAvailability = async (req, res) => {
  try {
    const disableToday =
      req.query.disableToday === "true";

    const daysAhead = 30;

    const startDateString =
      getISTDateString();

    const start =
      new Date(startDateString);

    if (disableToday) {
      start.setDate(
        start.getDate() + 1
      );
    }

    const startDateStr =
      start.toLocaleDateString(
        "en-CA",
        {
          timeZone: "Asia/Kolkata"
        }
      );

    const rules =
      await getPrioritySettings();

    await ensureDateRange(
      start,
      daysAhead
    );

    const [rows] = await db.execute(
      `
      SELECT
        d.date,
        d.appointment_total,
        d.appointment_booked,
        h.reason AS holiday_reason,
        wd.reason AS working_reason
      FROM daily_slots d
      LEFT JOIN holidays h
        ON h.date = d.date
      LEFT JOIN working_days wd
        ON wd.date = d.date
      WHERE d.date >= ?
      ORDER BY d.date ASC
      `,
      [startDateStr]
    );

    const workingDays = [];

    for (const r of rows) {
      const dateObj =
        new Date(r.date);

      const day =
        dateObj.getDay();

      const isWeekend =
        day === 0 ||
        day === 6;

      const isSpecialWorkingDay =
        !!r.working_reason;

      const isGazettedHoliday =
        !!r.holiday_reason;

      let isHoliday = false;

      if (isGazettedHoliday) {
        isHoliday = true;
      } else if (
        isWeekend &&
        !isSpecialWorkingDay
      ) {
        isHoliday = true;
      }

      if (isHoliday) {
        continue;
      }

      const available =
        Math.max(
          r.appointment_total -
          r.appointment_booked,
          0
        );

      const visibleDays =
        Number(
          rules.appointment_days_visible
        ) || 10;

      workingDays.push({
        date: r.date,
        appointment_total:
          r.appointment_total,
        appointment_booked:
          r.appointment_booked,
        available_slots:
          available,
        status:
          available <= 0
            ? "FULL"
            : "AVAILABLE",
        holiday_reason: null
      });

      if (
        workingDays.length ===
        visibleDays
      ) {
        break;
      }
    }

    res.json(workingDays);

  } catch (e) {
    console.error(
      "[availability] Error:",
      e.message
    );

    res.status(500).json({
      message: "Availability error"
    });
  }
};


exports.getWalkinAvailability = async (
  req,
  res
) => {
  try {
    const hour =
      getISTHour();

    const today =
      getISTDateString();

    const rules =
      await getPrioritySettings();

    const walkinStartHour =
      Number(
        rules.walkin_start_hour
      ) || 6;

    const [rows] = await db.execute(
      `
      SELECT
        appointment_total,
        appointment_booked,
        walkin_total,
        walkin_booked,
        carry_forward_done
      FROM daily_slots
      WHERE date = ?
      `,
      [today]
    );

    const row = rows[0];

    if (!row) {
      return res.status(500).json({
        message: "DB error"
      });
    }

    const available =
      Math.max(
        row.walkin_total -
        row.walkin_booked,
        0
      );

    res.json({
      date: today,
      total_slots:
        row.walkin_total,
      used_slots:
        row.walkin_booked,
      available_slots:
        available
    });

  } catch (e) {
    console.error(
      "[walkin-availability] Error:",
      e.message
    );

    res.status(500).json({
      message: "DB error"
    });
  }
};