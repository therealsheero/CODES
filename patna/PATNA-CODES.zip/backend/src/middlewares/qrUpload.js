const multer = require("multer");
const path = require("path");


const storage = multer.diskStorage({

    destination:(req,file,cb)=>{

        cb(
            null,
            path.join(
                __dirname,
                "../../../frontend/assets/QRs"
            )
        );

    },


    filename:(req,file,cb)=>{

        const type=req.params.type;


        let name="";


        if(type==="dob"){
            name="dobqr.png";
        }


        else if(type==="name"){
            name="nameqr.png";
        }


        else if(type==="reactivation"){
            name="reactqr.png";
        }


        cb(null,name);

    }


});


const upload =
multer({

storage,

fileFilter:(req,file,cb)=>{


    if(
        file.mimetype.startsWith("image/")
    ){
        cb(null,true);
    }

    else{

        cb(
            new Error("Only images allowed")
        );

    }


}


});


module.exports=upload;
