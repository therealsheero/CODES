const db = require("../models/db");

function timeToMinutes(str) {
    if (!str) return 0;

    const [h, m] = str.split(":").map(Number);
    return h * 60 + m;
}

function getISTMinutes() {
    const parts = new Intl.DateTimeFormat("en-GB", {
        timeZone: "Asia/Kolkata",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
    }).formatToParts(new Date());

    const h = Number(
        parts.find(p => p.type === "hour").value
    );

    const m = Number(
        parts.find(p => p.type === "minute").value
    );

    return h * 60 + m;
}

module.exports = async (req, res, next) => {
    if (req.body.mode !== "W") {
        return next();
    }

    try {
        const [rows] = await db.execute(
            `SELECT rule_key, rule_value
             FROM priority_rules
             WHERE rule_key IN ('walkin_start_hour', 'walkin_end_hour')`
        );

        const rules = {};

        rows.forEach(r => {
            rules[r.rule_key] = r.rule_value;
        });

        if (!rules.walkin_start_hour || !rules.walkin_end_hour) {
            return res.status(503).json({
                message: "Walk-in timing not configured"
            });
        }

        const current = getISTMinutes();

        const start = timeToMinutes(
            rules.walkin_start_hour
        );

        const end = timeToMinutes(
            rules.walkin_end_hour
        );

        if (current < start || current >= end) {
            return res.status(403).json({
                message: `Walk-in booking allowed only between ${rules.walkin_start_hour} and ${rules.walkin_end_hour}`
            });
        }

        next();

    } catch (err) {
        console.error(
            "[timeWindow] DB error:",
            err.message
        );

        return res.status(500).json({
            message: "Server error"
        });
    }
};