const multer = require("multer");
const path = require("path");


const storage = multer.diskStorage({

destination:(req,file,cb)=>{

cb(
null,
"../frontend/js/geojson"
);

},


filename:(req,file,cb)=>{


cb(
null,
"current.geojson"
);


}

});


module.exports =
multer({

storage,


fileFilter:(req,file,cb)=>{


if(
path.extname(file.originalname)
!== ".geojson"
){

return cb(
new Error("Only GeoJSON allowed")
);

}


cb(null,true);


}

});
