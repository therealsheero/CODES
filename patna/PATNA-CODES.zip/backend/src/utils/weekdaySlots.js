const db = require("../models/db");

async function getWeekdaySlots(date) {
  const day = new Date(date).getDay();

  const [rows] = await db.execute(
    `
    SELECT
      appointment_total,
      walkin_total
    FROM weekday_slot_rules
    WHERE weekday = ?
    `,
    [day]
  );

  const row = rows[0];

  if (!row) {
    return {
      appointment: 140,
      walkin: 70
    };
  }

  return {
    appointment: row.appointment_total,
    walkin: row.walkin_total
  };
}

module.exports = {
  getWeekdaySlots
};