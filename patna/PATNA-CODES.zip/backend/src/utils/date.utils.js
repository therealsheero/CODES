function getISTDateString() {

    return new Intl.DateTimeFormat(
        "en-CA",
        {
            timeZone: "Asia/Kolkata",
            year:"numeric",
            month:"2-digit",
            day:"2-digit"
        }
    ).format(new Date());

}



function getISTDateTimeString(){

    return new Intl.DateTimeFormat(
        "sv-SE",
        {
            timeZone:"Asia/Kolkata",
            year:"numeric",
            month:"2-digit",
            day:"2-digit",
            hour:"2-digit",
            minute:"2-digit",
            second:"2-digit",
            hour12:false
        }
    ).format(new Date());

}


function getISTHour(){

    return Number(
        new Intl.DateTimeFormat(
            "en-IN",
            {
                timeZone:"Asia/Kolkata",
                hour:"2-digit",
                hour12:false
            }
        ).format(new Date())
    );

}



module.exports={
    getISTDateString,
    getISTDateTimeString,
    getISTHour
};
