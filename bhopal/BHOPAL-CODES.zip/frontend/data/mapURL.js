const fs = require("fs");
const path = require("path");
const file = path.join(__dirname, "ask-addresses.json");

const data = JSON.parse(fs.readFileSync(file, "utf8"));

for (const location of data) {
    if (location.address && location.address !== "Coming Soon") {
        location.mapUrl =
            `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                `${location.address}, ${location.city}, Uttar Pradesh, India`
            )}`;
    }
}

fs.writeFileSync(file, JSON.stringify(data, null, 2));

console.log(`Updated ${data.length} locations.`);