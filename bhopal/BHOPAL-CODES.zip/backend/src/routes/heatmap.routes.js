const express = require("express");

const router = express.Router();

const heatmapController =
  require("../controllers/heatmap.controller");

router.get(
  "/heatmap-data",
  heatmapController.getHeatmapData
);
router.get(
    "/district-residents",
    heatmapController.getDistrictResidents
);

router.get(
"/physical-district-residents",
heatmapController.getPhysicalDistrictResidents
);

router.get(
"/slot-summary",
heatmapController.getSlotSummary
);
module.exports = router;