-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: generatetoken-mysql.mysql.database.azure.com    Database: bhopal_token
-- ------------------------------------------------------
-- Server version	8.0.46-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `daily_slots`
--

DROP TABLE IF EXISTS `daily_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_slots` (
  `date` date NOT NULL,
  `appointment_total` int DEFAULT NULL,
  `appointment_booked` int DEFAULT '0',
  `walkin_total` int DEFAULT NULL,
  `walkin_booked` int DEFAULT '0',
  `carry_forward_done` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_slots`
--

LOCK TABLES `daily_slots` WRITE;
/*!40000 ALTER TABLE `daily_slots` DISABLE KEYS */;
INSERT INTO `daily_slots` VALUES ('2026-09-26',0,0,0,0,0),('2026-09-27',0,0,0,0,0),('2026-09-28',100,1,60,0,0),('2026-09-29',100,0,60,0,0),('2026-09-30',100,0,60,0,0),('2026-10-01',100,0,60,0,0),('2026-10-02',100,0,60,0,0),('2026-10-03',0,0,0,0,0),('2026-10-04',0,0,0,0,0),('2026-10-05',100,0,60,0,0),('2026-10-06',100,0,60,0,0),('2026-10-07',100,0,60,0,0),('2026-10-08',100,0,60,0,0),('2026-10-09',100,0,60,0,0),('2026-10-10',0,0,0,0,0),('2026-10-11',0,0,0,0,0),('2026-10-12',100,0,60,0,0),('2026-10-13',100,0,60,0,0),('2026-10-14',100,0,60,0,0),('2026-10-15',100,0,60,0,0),('2026-10-16',100,0,60,0,0),('2026-10-17',0,0,0,0,0),('2026-10-18',0,0,0,0,0),('2026-10-19',100,0,60,0,0),('2026-10-20',100,0,60,0,0),('2026-10-21',100,0,60,0,0),('2026-10-22',100,0,60,0,0),('2026-10-23',100,0,60,0,0),('2026-10-24',0,0,0,0,0),('2026-10-25',0,0,0,0,0),('2026-10-26',100,0,60,0,0);
/*!40000 ALTER TABLE `daily_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_token_counters`
--

DROP TABLE IF EXISTS `daily_token_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_token_counters` (
  `date` date NOT NULL,
  `priority_count` int DEFAULT '0',
  `normal_count` int DEFAULT '0',
  `wp_count` int DEFAULT '0',
  `wn_count` int DEFAULT '0',
  `ap_count` int DEFAULT '0',
  `an_count` int DEFAULT '0',
  `last_token` int DEFAULT '0',
  `wl_count` int DEFAULT '0',
  `al_count` int DEFAULT '0',
  `tokens_per_hour` int DEFAULT '40',
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_token_counters`
--

LOCK TABLES `daily_token_counters` WRITE;
/*!40000 ALTER TABLE `daily_token_counters` DISABLE KEYS */;
INSERT INTO `daily_token_counters` VALUES ('2026-09-28',0,0,0,0,0,1,1,0,0,12);
/*!40000 ALTER TABLE `daily_token_counters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_field_settings`
--

DROP TABLE IF EXISTS `dashboard_field_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_field_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dashboard` varchar(255) NOT NULL,
  `field_key` varchar(255) NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `display_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dashboard_field` (`dashboard`,`field_key`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_field_settings`
--

LOCK TABLES `dashboard_field_settings` WRITE;
/*!40000 ALTER TABLE `dashboard_field_settings` DISABLE KEYS */;
INSERT INTO `dashboard_field_settings` VALUES (1,'MANAGER','id',0,1),(2,'MANAGER','token',0,2),(3,'MANAGER','name',1,6),(4,'MANAGER','mobile',1,7),(5,'MANAGER','aadhaar_last4',1,3),(6,'MANAGER','age',1,9),(7,'MANAGER','gender',1,8),(8,'MANAGER','divyang',0,8),(9,'MANAGER','district',1,12),(10,'MANAGER','service_type',1,13),(11,'MANAGER','qrc',0,11),(12,'MANAGER','date',1,2),(13,'MANAGER','mode',0,13),(14,'MANAGER','priority',0,14),(15,'MANAGER','created_at',1,1),(16,'MANAGER','device_id',0,16),(17,'MANAGER','token_type',1,4),(18,'MANAGER','visited',0,18),(19,'MANAGER','visited_at',1,16),(20,'MANAGER','distance_meters',0,20),(21,'MANAGER','token_seq',0,21),(22,'MANAGER','entry_marked',0,22),(23,'MANAGER','entry_time',1,15),(24,'MANAGER','eid',0,24),(25,'MANAGER','identity_type',0,25),(26,'MANAGER','sid',0,26),(27,'MANAGER','hardware_fp',0,27),(28,'MANAGER','service_other',0,28),(29,'GUARD','id',0,1),(30,'GUARD','token',0,2),(31,'GUARD','name',1,6),(32,'GUARD','mobile',1,7),(33,'GUARD','aadhaar_last4',0,5),(34,'GUARD','age',1,9),(35,'GUARD','gender',1,8),(36,'GUARD','divyang',0,8),(37,'GUARD','district',1,12),(38,'GUARD','service_type',1,13),(39,'GUARD','qrc',0,11),(40,'GUARD','date',1,2),(41,'GUARD','mode',0,13),(42,'GUARD','priority',0,14),(43,'GUARD','created_at',1,1),(44,'GUARD','device_id',0,16),(45,'GUARD','token_type',1,4),(46,'GUARD','visited',0,18),(47,'GUARD','visited_at',0,16),(48,'GUARD','distance_meters',0,20),(49,'GUARD','token_seq',0,21),(50,'GUARD','entry_marked',0,22),(51,'GUARD','entry_time',0,15),(52,'GUARD','eid',0,24),(53,'GUARD','identity_type',0,25),(54,'GUARD','sid',0,26),(55,'GUARD','hardware_fp',0,27),(56,'GUARD','service_other',0,28),(57,'GUARD2','id',0,1),(58,'GUARD2','token',0,2),(59,'GUARD2','name',1,6),(60,'GUARD2','mobile',1,7),(61,'GUARD2','aadhaar_last4',0,5),(62,'GUARD2','age',1,9),(63,'GUARD2','gender',1,8),(64,'GUARD2','divyang',0,8),(65,'GUARD2','district',1,12),(66,'GUARD2','service_type',1,13),(67,'GUARD2','qrc',0,11),(68,'GUARD2','date',1,2),(69,'GUARD2','mode',0,13),(70,'GUARD2','priority',0,14),(71,'GUARD2','created_at',1,1),(72,'GUARD2','device_id',0,16),(73,'GUARD2','token_type',1,4),(74,'GUARD2','visited',0,18),(75,'GUARD2','visited_at',1,16),(76,'GUARD2','distance_meters',0,20),(77,'GUARD2','token_seq',0,21),(78,'GUARD2','entry_marked',0,22),(79,'GUARD2','entry_time',1,15),(80,'GUARD2','eid',0,24),(81,'GUARD2','identity_type',0,25),(82,'GUARD2','sid',0,26),(83,'GUARD2','hardware_fp',0,27),(84,'GUARD2','service_other',0,28),(85,'MANAGER','token_count',1,3),(87,'MANAGER','identity',1,5),(88,'MANAGER','expected_time',1,14),(89,'MANAGER','time_taken',1,17),(90,'MANAGER','reference_of',1,18),(91,'GUARD','token_count',1,3),(93,'GUARD','expected_time',1,14),(94,'GUARD2','token_count',1,3),(96,'GUARD2','expected_time',0,14);
/*!40000 ALTER TABLE `dashboard_field_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `district_visit_history`
--

DROP TABLE IF EXISTS `district_visit_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `district_visit_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `mode` varchar(50) DEFAULT NULL,
  `eid_type` varchar(50) DEFAULT NULL,
  `visits` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `district_visit_history`
--

LOCK TABLES `district_visit_history` WRITE;
/*!40000 ALTER TABLE `district_visit_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `district_visit_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `districts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `english_name` varchar(255) NOT NULL,
  `hindi_name` varchar(255) NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `english_name` (`english_name`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `districts`
--

LOCK TABLES `districts` WRITE;
/*!40000 ALTER TABLE `districts` DISABLE KEYS */;
INSERT INTO `districts` VALUES (1,'Agar Malwa','आगर मालवा',1),(2,'Alirajpur','अलीराजपुर',1),(3,'Anuppur','अनूपपुर',1),(4,'Ashoknagar','अशोकनगर',1),(5,'Balaghat','बालाघाट',1),(6,'Barwani','बड़वानी',1),(7,'Betul','बैतूल',1),(8,'Bhind','भिंड',1),(9,'Bhopal','भोपाल',1),(10,'Burhanpur','बुरहानपुर',1),(11,'Chhatarpur','छतरपुर',1),(12,'Chhindwara','छिंदवाड़ा',1),(13,'Damoh','दमोह',1),(14,'Datia','दतिया',1),(15,'Dewas','देवास',1),(16,'Dhar','धार',1),(17,'Dindori','डिंडोरी',1),(18,'Guna','गुना',1),(19,'Gwalior','ग्वालियर',1),(20,'Harda','हरदा',1),(21,'Narmadapuram','नर्मदापुरम',1),(22,'Indore','इंदौर',1),(23,'Jabalpur','जबलपुर',1),(24,'Jhabua','झाबुआ',1),(25,'Katni','कटनी',1),(26,'Khandwa (East Nimar)','खंडवा (पूर्व निमाड़)',1),(27,'Khargone (West Nimar)','खरगोन (पश्चिम निमाड़)',1),(28,'Maihar','मैहर',1),(29,'Mandla','मंडला',1),(30,'Mandsaur','मंदसौर',1),(31,'Mauganj','मऊगंज',1),(32,'Morena','मुरैना',1),(33,'Narsinghpur','नरसिंहपुर',1),(34,'Neemuch','नीमच',1),(35,'Niwari','निवाड़ी',1),(36,'Panna','पन्ना',1),(37,'Pandhurna','पांढुर्णा',1),(38,'Raisen','रायसेन',1),(39,'Rajgarh','राजगढ़',1),(40,'Ratlam','रतलाम',1),(41,'Rewa','रीवा',1),(42,'Sagar','सागर',1),(43,'Satna','सतना',1),(44,'Sehore','सीहोर',1),(45,'Seoni','सिवनी',1),(46,'Shahdol','शहडोल',1),(47,'Shajapur','शाजापुर',1),(48,'Sheopur','श्योपुर',1),(49,'Shivpuri','शिवपुरी',1),(50,'Sidhi','सीधी',1),(51,'Singrauli','सिंगरौली',1),(52,'Tikamgarh','टीकमगढ़',1),(53,'Ujjain','उज्जैन',1),(54,'Umaria','उमरिया',1),(55,'Vidisha','विदिशा',1);
/*!40000 ALTER TABLE `districts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_settings`
--

DROP TABLE IF EXISTS `form_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `field_key` varchar(255) NOT NULL,
  `field_label` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `mandatory` tinyint(1) DEFAULT '1',
  `display_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `field_key` (`field_key`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_settings`
--

LOCK TABLES `form_settings` WRITE;
/*!40000 ALTER TABLE `form_settings` DISABLE KEYS */;
INSERT INTO `form_settings` VALUES (1,'qrc','QRC Number',1,1,1),(2,'name','Name',1,1,2),(3,'mobile','Mobile Number',1,1,3),(4,'aadhaar_last4','Aadhaar Last 4',1,1,4),(5,'gender','Gender',1,1,5),(6,'age','Age',1,1,6),(7,'district','District',1,1,7),(8,'identity','EID/SID Details',1,1,8),(9,'consent','Consent Checkbox',1,1,9);
/*!40000 ALTER TABLE `form_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geojson_settings`
--

DROP TABLE IF EXISTS `geojson_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `geojson_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_path` text NOT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geojson_settings`
--

LOCK TABLES `geojson_settings` WRITE;
/*!40000 ALTER TABLE `geojson_settings` DISABLE KEYS */;
INSERT INTO `geojson_settings` VALUES (1,'current.geojson','/js/geojson/current.geojson','2026-09-26 12:21:22');
/*!40000 ALTER TABLE `geojson_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `holidays` (
  `date` date NOT NULL,
  `reason` text,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holidays`
--

LOCK TABLES `holidays` WRITE;
/*!40000 ALTER TABLE `holidays` DISABLE KEYS */;
INSERT INTO `holidays` VALUES ('2026-03-04','Holi'),('2026-03-21','Id-ul-Fitr'),('2026-03-26','Ram Navmi'),('2026-03-31','Mahavir Jayanti'),('2026-04-03','Good Friday'),('2026-04-14','Ambedkar Jayanti'),('2026-05-01','Buddha Purnima'),('2026-05-28','Bakrid (Eid al-Adha)'),('2026-06-26','Muharram'),('2026-08-15','Independence Day'),('2026-08-26','Milan-un-Nabi'),('2026-09-04','Janmashtami'),('2026-10-02','Gandhi Jayanti'),('2026-10-20','Dusshera'),('2026-11-08','Diwali'),('2026-11-24','Guru Nakak Jayanti'),('2026-12-25','Christmas Day');
/*!40000 ALTER TABLE `holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logo_settings`
--

DROP TABLE IF EXISTS `logo_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logo_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` text,
  `is_active` tinyint(1) DEFAULT '1',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logo_settings`
--

LOCK TABLES `logo_settings` WRITE;
/*!40000 ALTER TABLE `logo_settings` DISABLE KEYS */;
INSERT INTO `logo_settings` VALUES (1,'department_logo','logo.png','assets/logo/logo.png',1,'2026-07-28 13:32:58');
/*!40000 ALTER TABLE `logo_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notices` (
  `date` date NOT NULL,
  `message` text,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notices`
--

LOCK TABLES `notices` WRITE;
/*!40000 ALTER TABLE `notices` DISABLE KEYS */;
INSERT INTO `notices` VALUES ('2026-04-10','The Regional Office Lucknow shall remain closed on 14th April as it has been declared a holiday on account of birthday of Dr. B.R. Ambedkar/ डॉ. बी.आर. अंबेडकर के जन्मदिन के उपलक्ष्य में 14 अप्रैल को अवकाश घोषित होने के कारण क्षेत्रीय कार्यालय लखनऊ बंद रहेगा।'),('2026-04-13','The Regional Office Lucknow shall remain closed on 14th April as it has been declared a holiday on account of birthday of Dr. B.R. Ambedkar/ डॉ. बी.आर. अंबेडकर के जन्मदिन के उपलक्ष्य में 14 अप्रैल को अवकाश घोषित होने के कारण क्षेत्रीय कार्यालय लखनऊ बंद रहेगा।'),('2026-05-25','Dear Resident, This is to inform you that 28.05.2026 has been declared a holiday by the Central Government. Therefore, your appointment booked for 28.05.2026 is cancelled and you are requested to book an appointment on another date. We apologize for the inconvenience caused./ प्रिय निवासी, आपको अवगत कराना है कि दिनांक 28.05.2026 को केंद्र सरकार द्वारा अवकाश की घोषणा की गई है। अतएव आपके द्वारा बुक दिनांक 28.05.2026 की appointment को निरस्त किया जाता है साथ ही आपसे किसी अन्य तिथि में appointment बुक करने का आग्रह किया जाता है। आपको हुई असुविधा के लिए हमें खेद है।'),('2026-05-26','Dear Resident, This is to inform you that 28.05.2026 has been declared a holiday by the Central Government. Therefore, your appointment booked for 28.05.2026 is cancelled and you are requested to book an appointment on another date. We apologize for the inconvenience caused./ प्रिय निवासी, आपको अवगत कराना है कि दिनांक 28.05.2026 को केंद्र सरकार द्वारा अवकाश की घोषणा की गई है। अतएव आपके द्वारा बुक दिनांक 28.05.2026 की appointment को निरस्त किया जाता है साथ ही आपसे किसी अन्य तिथि में appointment बुक करने का आग्रह किया जाता है। आपको हुई असुविधा के लिए हमें खेद है।'),('2026-06-03','26-06-2026 is a declared holiday on account of Muharram/  मुहर्रम के उपलक्ष्य में 26-06-2026 को अवकाश घोषित किया गया है।');
/*!40000 ALTER TABLE `notices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_verifications`
--

DROP TABLE IF EXISTS `otp_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `otp_verifications` (
  `mobile` varchar(20) NOT NULL,
  `otp` varchar(20) DEFAULT NULL,
  `expires_at` bigint DEFAULT NULL,
  `attempts` int DEFAULT '0',
  `verified` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_verifications`
--

LOCK TABLES `otp_verifications` WRITE;
/*!40000 ALTER TABLE `otp_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `otp_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physical_reference_entries`
--

DROP TABLE IF EXISTS `physical_reference_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `physical_reference_entries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `aadhaar_last4` varchar(4) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `service_type` varchar(255) DEFAULT NULL,
  `token_type` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `token` varchar(100) DEFAULT NULL,
  `reference_of` varchar(255) DEFAULT NULL,
  `eid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physical_reference_entries`
--

LOCK TABLES `physical_reference_entries` WRITE;
/*!40000 ALTER TABLE `physical_reference_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `physical_reference_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priority_districts`
--

DROP TABLE IF EXISTS `priority_districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priority_districts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `district` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `district` (`district`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priority_districts`
--

LOCK TABLES `priority_districts` WRITE;
/*!40000 ALTER TABLE `priority_districts` DISABLE KEYS */;
/*!40000 ALTER TABLE `priority_districts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priority_rules`
--

DROP TABLE IF EXISTS `priority_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priority_rules` (
  `rule_key` varchar(255) NOT NULL,
  `rule_value` text,
  PRIMARY KEY (`rule_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priority_rules`
--

LOCK TABLES `priority_rules` WRITE;
/*!40000 ALTER TABLE `priority_rules` DISABLE KEYS */;
INSERT INTO `priority_rules` VALUES ('appointment_days_visible','5'),('child_age_limit','5'),('default_appointment_slots','100'),('default_tokens_per_hour','null'),('default_walkin_slots','60'),('female_priority_age','55'),('gazette_office_address','UIDAI State Office, Ground Floor, BSNL Bhawan, Near Paryawas Bhawan, Arera Hills, Bhopal - 462026, Madhya Pradesh'),('geo_end_1','09:00'),('geo_end_2','15:00'),('geo_start_1','05:00'),('geo_start_2','11:00'),('geofence_distance_meters','50'),('geofence_stop_hour','11'),('manager_future_days','13'),('manager_previous_days','1'),('office_display_en','This is for UIDAI State Office Bhopal, UIDAI State Office, Ground Floor, BSNL Bhawan, Near Paryawas Bhawan, Arera Hills, Bhopal - 462026, Madhya Pradesh'),('office_display_hi','यह केवल यूआईडीएआई आरओ लखनऊ, तीसरी मंजिल, उत्तर प्रदेश समाज कल्याण निर्माण निगम बिल्डिंग, टीसी-46/वी, विभूति खंड, गोमती नगर, लखनऊ-226010 के लिए मान्य है।'),('office_latitude','23.23728553850184'),('office_longitude','77.42892'),('office_open_saturday',NULL),('office_open_sunday',NULL),('office_short_name','SO BHOPAL'),('senior_age_limit','60'),('today_appointment_cutoff_hour','08:00'),('walkin_end_hour','14:00'),('walkin_start_hour','08:00'),('watermark_text','RO-BPL');
/*!40000 ALTER TABLE `priority_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qr_settings`
--

DROP TABLE IF EXISTS `qr_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `qr_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `qr_type` varchar(255) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` text,
  `is_active` tinyint(1) DEFAULT '1',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `qr_type` (`qr_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qr_settings`
--

LOCK TABLES `qr_settings` WRITE;
/*!40000 ALTER TABLE `qr_settings` DISABLE KEYS */;
INSERT INTO `qr_settings` VALUES (1,'dob','dobqr.png','assets/QRs/dobqr.png',1,'2026-07-27 11:57:21'),(2,'name','nameqr.png','assets/QRs/nameqr.png',1,'2026-07-27 11:59:09'),(3,'reactivation','reactqr.png','assets/QRs/reactqr.png',1,'2026-07-27 05:59:45');
/*!40000 ALTER TABLE `qr_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_form_settings`
--

DROP TABLE IF EXISTS `service_form_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_form_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_type_id` int NOT NULL,
  `field_key` varchar(255) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `mandatory` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_service_form_service_type` (`service_type_id`),
  CONSTRAINT `fk_service_form_service_type` FOREIGN KEY (`service_type_id`) REFERENCES `service_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_form_settings`
--

LOCK TABLES `service_form_settings` WRITE;
/*!40000 ALTER TABLE `service_form_settings` DISABLE KEYS */;
INSERT INTO `service_form_settings` VALUES (2,6,'qrc',1,1),(3,1,'qrc',1,1),(4,4,'qrc',1,1),(5,7,'qrc',1,1),(6,5,'qrc',1,1),(7,2,'qrc',1,1),(8,11,'qrc',1,1),(10,6,'name',1,1),(11,1,'name',1,1),(12,4,'name',1,1),(13,7,'name',1,1),(14,5,'name',1,1),(15,2,'name',1,1),(16,11,'name',1,1),(18,6,'mobile',1,1),(19,1,'mobile',1,1),(20,4,'mobile',1,1),(21,7,'mobile',1,1),(22,5,'mobile',1,1),(23,2,'mobile',1,1),(24,11,'mobile',1,1),(26,6,'aadhaar_last4',1,1),(27,1,'aadhaar_last4',1,1),(28,4,'aadhaar_last4',1,1),(29,7,'aadhaar_last4',1,1),(30,5,'aadhaar_last4',1,1),(31,2,'aadhaar_last4',1,1),(32,11,'aadhaar_last4',1,1),(34,6,'gender',1,1),(35,1,'gender',1,1),(36,4,'gender',1,1),(37,7,'gender',1,1),(38,5,'gender',1,1),(39,2,'gender',1,1),(40,11,'gender',1,1),(42,6,'age',1,1),(43,1,'age',1,1),(44,4,'age',1,1),(45,7,'age',1,1),(46,5,'age',1,1),(47,2,'age',1,1),(48,11,'age',1,1),(50,6,'district',1,1),(51,1,'district',1,1),(52,4,'district',1,1),(53,7,'district',1,1),(54,5,'district',1,1),(55,2,'district',1,1),(56,11,'district',1,1),(58,6,'identity',1,1),(59,1,'identity',1,1),(60,4,'identity',1,1),(61,7,'identity',1,1),(62,5,'identity',1,1),(63,2,'identity',1,1),(64,11,'identity',1,1),(66,6,'consent',1,1),(67,1,'consent',1,1),(68,4,'consent',1,1),(69,7,'consent',1,1),(70,5,'consent',1,1),(71,2,'consent',1,1),(72,11,'consent',1,1),(91,15,'qrc',1,1),(92,15,'name',1,1),(93,15,'mobile',1,1),(94,15,'aadhaar_last4',1,1),(95,15,'gender',1,1),(96,15,'age',1,1),(97,15,'district',1,1),(98,15,'identity',1,1),(99,15,'consent',1,1);
/*!40000 ALTER TABLE `service_form_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_types`
--

DROP TABLE IF EXISTS `service_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `english_name` varchar(255) NOT NULL,
  `hindi_name` varchar(255) NOT NULL,
  `requires_eid` tinyint(1) DEFAULT '0',
  `requires_sid` tinyint(1) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `display_order` int DEFAULT '0',
  `requires_identity` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `english_name` (`english_name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_types`
--

LOCK TABLES `service_types` WRITE;
/*!40000 ALTER TABLE `service_types` DISABLE KEYS */;
INSERT INTO `service_types` VALUES (1,'DoB','जन्मतिथि',1,0,1,1,1),(2,'Name','नाम',1,0,1,2,1),(4,'Gender','लिंग',1,0,1,4,1),(5,'Lost Aadhaar','आधार कार्ड खो गया',0,0,1,5,0),(6,'Biometric Issue','बायोमेट्रिक समस्या',1,0,1,6,1),(7,'Lock Aadhaar','आधार कार्ड लॉक',0,0,1,7,0),(11,'None of the above','इनमें से कोई नहीं',0,0,1,8,0),(15,'Cancelled Aadhaar/ Aadhaar Suspended','आधार रद्द या आधार सस्पेंड कर दिया गया है',0,0,1,0,0);
/*!40000 ALTER TABLE `service_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` varchar(100) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `aadhaar_last4` varchar(4) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `divyang` varchar(50) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `service_type` varchar(255) DEFAULT NULL,
  `qrc` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `mode` varchar(50) DEFAULT NULL,
  `priority` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `device_id` varchar(255) DEFAULT NULL,
  `token_type` varchar(50) DEFAULT NULL,
  `visited` tinyint(1) DEFAULT '0',
  `visited_at` datetime DEFAULT NULL,
  `distance_meters` int DEFAULT NULL,
  `token_seq` int DEFAULT NULL,
  `entry_marked` tinyint(1) DEFAULT '0',
  `entry_time` datetime DEFAULT NULL,
  `eid` varchar(100) DEFAULT NULL,
  `identity_type` varchar(100) DEFAULT NULL,
  `sid` varchar(100) DEFAULT NULL,
  `hardware_fp` varchar(255) DEFAULT NULL,
  `service_other` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_token_seq_per_day` (`date`,`token_seq`),
  KEY `idx_tokens_date` (`date`),
  KEY `idx_tokens_visited` (`visited`),
  KEY `idx_tokens_service` (`service_type`),
  KEY `idx_tokens_mode` (`mode`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (1,'001-AN-4344','Shreeya','7616122929','4344',23,'Female',NULL,'Indore','Name','S1289110101000','2026-09-28','A','N','2026-09-26 12:48:09','DEV-2fb8c426-750e-4177-b0bf-2efd72d1f44d','AN',0,NULL,534838,1,0,NULL,NULL,'SID','S109229829292918126266221718','HW-417c8e2419c166398c6b6f78de7bea8858205cceaf63bfe700cfc0be2706d978',NULL);
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(100) NOT NULL,
  `session_name` varchar(255) NOT NULL,
  `page` varchar(255) NOT NULL,
  `recovery_code` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'operator','$2b$10$zrS18RttdrMXueiEq7EMKOA67ZCAhaV1bjHyLjWKn0bcLJeo/4pnu','SERVICE_COUNTER','GUARD2_SESSION','guard2.html',NULL,1),(2,'admin','$2b$10$wbRuaSKsUIeSkeYt.rj8/evvlio4mYv5Y2.H94DVkX3rwELUpRHGu','MANAGER','MANAGER_SESSION','manager.html','LkoTS#110726',1),(3,'guard','$2b$10$NdaP.Sd1DnOTUZYyv7lj4uUiXxlaRKSgxjhtAHRvuXtrpoDWxsNha','GUARD','GUARD_SESSION','guard.html',NULL,1),(4,'guard3','$2b$10$PREAAi3zIXQm821jGbj7WuHPXhin2A/ysDxb6ntYVRKFIQLeqcmP.','GUARD3','GUARD3_SESSION','guard3.html',NULL,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weekday_slot_rules`
--

DROP TABLE IF EXISTS `weekday_slot_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weekday_slot_rules` (
  `weekday` int NOT NULL,
  `weekday_name` varchar(50) NOT NULL,
  `appointment_total` int NOT NULL,
  `walkin_total` int NOT NULL,
  `tokens_per_hour` int DEFAULT '30',
  `work_start_time` time DEFAULT NULL,
  PRIMARY KEY (`weekday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekday_slot_rules`
--

LOCK TABLES `weekday_slot_rules` WRITE;
/*!40000 ALTER TABLE `weekday_slot_rules` DISABLE KEYS */;
INSERT INTO `weekday_slot_rules` VALUES (0,'Sunday',0,0,12,'09:30:00'),(1,'Monday',100,60,12,'09:30:00'),(2,'Tuesday',100,60,12,'09:30:00'),(3,'Wednesday',100,60,12,'09:30:00'),(4,'Thursday',100,60,12,'09:30:00'),(5,'Friday',100,60,12,'09:30:00'),(6,'Saturday',0,0,12,'09:30:00');
/*!40000 ALTER TABLE `weekday_slot_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_days`
--

DROP TABLE IF EXISTS `working_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_days` (
  `date` date NOT NULL,
  `reason` text,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_days`
--

LOCK TABLES `working_days` WRITE;
/*!40000 ALTER TABLE `working_days` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_days` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-26  9:46:40
