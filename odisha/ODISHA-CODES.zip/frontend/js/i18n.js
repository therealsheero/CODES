/**
 * Dynamic Multi-Language (i18n) Engine for UIDAI Token Portal
 * Lightweight, zero-dependency client-side translation framework.
 */
(function () {
  const LANGUAGES = [
    { code: "en", label: "English", native: "English" },
    { code: "hi", label: "Hindi", native: "हिन्दी" },
    { code: "bn", label: "Bengali", native: "বাংলা" },
    { code: "kn", label: "Kannada", native: "ಕನ್ನಡ" },
    { code: "ta", label: "Tamil", native: "தமிழ்" },
    { code: "te", label: "Telugu", native: "తెలుగు" },
    { code: "gu", label: "Gujarati", native: "ગુજરાતી" },
    { code: "ml", label: "Malayalam", native: "മലയാളം" },
    { code: "or", label: "Odia", native: "ଓଡ଼ିଆ" },
    { code: "mr", label: "Marathi", native: "मराठी" },
    { code: "as", label: "Assamese", native: "অসমীয়া" }
  ];

  let currentLang = "en";
  let dictionary = {};
  let fallbackDictionary = {};

  // Detect current language from localStorage
function detectLanguage() {

    // 1. First check language passed from the main state-selection page
    const params = new URLSearchParams(window.location.search);
    const urlLang = params.get("lang");

    if (
        urlLang &&
        LANGUAGES.some(l => l.code === urlLang)
    ) {

        // Save it for this portal's own origin
        localStorage.setItem("selected_lang", urlLang);
        localStorage.setItem("app_lang", urlLang);

        return urlLang;
    }


    // 2. Otherwise use this portal's saved language
    const saved =
        localStorage.getItem("selected_lang") ||
        localStorage.getItem("app_lang");

    if (
        saved &&
        LANGUAGES.some(l => l.code === saved)
    ) {
        return saved;
    }


    // 3. Default
    return "en";
}

  // Retrieve nested key value from object
  function getNestedValue(obj, keyPath) {
    if (!obj || !keyPath) return null;
    const keys = keyPath.split(".");
    let current = obj;
    for (let k of keys) {
      if (current && typeof current === "object" && k in current) {
        current = current[k];
      } else {
        return null;
      }
    }
    return typeof current === "string" ? current : null;
  }

  // Load JSON dictionary
  async function loadDictionary(lang) {
    try {
      const res = await fetch(`./lang/${lang}.json`);
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.warn(`[i18n] Failed to load /lang/${lang}.json`, e);
    }
    return null;
  }

  // Main translation apply function
  async function setLanguage(lang) {
    currentLang = lang;
    localStorage.setItem("selected_lang", lang);
    localStorage.setItem("app_lang", lang);

    // Load requested dictionary
    let data = await loadDictionary(lang);
    if (!data && lang !== "en") {
      data = await loadDictionary("en");
    }
    dictionary = data || {};

    // Ensure fallback dictionary (English) is loaded
    if (lang !== "en" && Object.keys(fallbackDictionary).length === 0) {
      fallbackDictionary = (await loadDictionary("en")) || {};
    }

    applyTranslations();
    updateDropdownUI();

    // Dispatch global event for custom JS re-rendering
    window.dispatchEvent(
      new CustomEvent("languageChanged", { detail: { lang: currentLang, t: window.t } })
    );
  }

  // Apply translations to DOM elements
  function applyTranslations() {
    // 1. Text Content elements
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      const key = el.getAttribute("data-i18n");
      const text = window.t(key);
      if (text) {
        el.textContent = text;
      }
    });

    // 2. HTML Content elements
    document.querySelectorAll("[data-i18n-html]").forEach((el) => {
      const key = el.getAttribute("data-i18n-html");
      const htmlText = window.t(key);
      if (htmlText) {
        el.innerHTML = htmlText;
      }
    });

    // 3. Placeholders
    document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
      const key = el.getAttribute("data-i18n-placeholder");
      const text = window.t(key);
      if (text) {
        el.placeholder = text;
      }
    });

    // 4. Titles / Tooltips
    document.querySelectorAll("[data-i18n-title]").forEach((el) => {
      const key = el.getAttribute("data-i18n-title");
      const text = window.t(key);
      if (text) {
        el.title = text;
      }
    });
  }

  // Inject or update Language Dropdown in Header
  function updateDropdownUI() {
    let selectEl = document.getElementById("langSelect");
    if (!selectEl) {
      const govRight = document.querySelector(".gov-header .gov-right");
      if (govRight) {
        const container = document.createElement("div");
        container.className = "gov-lang-container";
        container.innerHTML = `
          <select id="langSelect" class="gov-lang-select" aria-label="Select Language">
            ${LANGUAGES.map(
              (l) => `<option value="${l.code}">${l.native} (${l.label})</option>`
            ).join("")}
          </select>
        `;
        govRight.appendChild(container);
        selectEl = document.getElementById("langSelect");
      }
    }

    if (selectEl) {
      selectEl.value = currentLang;
      if (!selectEl.dataset.i18nBound) {
        selectEl.dataset.i18nBound = "true";
        selectEl.addEventListener("change", (e) => {
          setLanguage(e.target.value);
        });
      }
    }
  }

  // Global Translation helper function: window.t(key, fallback, replacements)
  window.t = function (key, fallback = "", replacements = {}) {
    let val = getNestedValue(dictionary, key);
    if (!val && currentLang !== "en") {
      val = getNestedValue(fallbackDictionary, key);
    }
    if (!val) {
      val = fallback || "";
    }

    // Dynamic string interpolation e.g., {count} -> 5
    if (val && replacements && typeof replacements === "object") {
      Object.keys(replacements).forEach((rk) => {
        val = val.replace(new RegExp(`\\{${rk}\\}`, "g"), replacements[rk]);
      });
    }

    return val;
  };

  // Expose i18n object globally
  window.i18n = {
    setLanguage,
    getLanguage: () => currentLang,
    getLanguages: () => LANGUAGES,
    applyTranslations
  };

  // Initialize on DOM ready
  document.addEventListener("DOMContentLoaded", () => {
    currentLang = detectLanguage();
    setLanguage(currentLang);
  });
})();
