const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const cors = require("cors");

const app = express();
app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(
  helmet({
    frameguard: {
      action: "deny"
    }
  })
);
// app.use(cors({
//   origin: function(origin, callback) {
//     if (!origin) {
//       return callback(null, true);
//     }
// 
//     if (
//       origin === "https://generatetoken.page" ||
//       origin.endsWith(".generatetoken.page")
//     ) {
//       return callback(null, true);
//     }
// 
//     return callback(new Error("Not allowed by CORS"));
//   },
//   methods: ["GET", "POST", "PUT", "DELETE"],
//   credentials: true
// }));
app.use(express.json()); 
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 2000,
  message: {
    message: "Too many requests"
  }
});

app.use("/api", apiLimiter);
app.get("/", (req, res) => {
  res.send("Appointment Token System API is running");
});

module.exports = app;
