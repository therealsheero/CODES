

const managerToken = localStorage.getItem("managerToken");

if (!managerToken) {
  window.location.href = "manager-login.html";
}

async function loadSettings() {

  const res = await fetch("/gujarat/api/settings/priority-settings", {
    headers: { "x-manager-token": managerToken }
  });

  const data = await res.json();

  const rules = {};
  data.rules.forEach(r => rules[r.rule_key] = r.rule_value);

  document.getElementById("childAge").value = rules.child_age_limit;
  document.getElementById("seniorAge").value = rules.senior_age_limit;
  document.getElementById("femaleAge").value = rules.female_priority_age;



    document.getElementById("appointmentDays").value =
    rules.appointment_days_visible;

document.getElementById("walkinStartHour").value =
rules.walkin_start_hour.includes(":")
? rules.walkin_start_hour
: String(rules.walkin_start_hour).padStart(2,"0")+":00";

document.getElementById("walkinEndHour").value =
rules.walkin_end_hour.includes(":")
? rules.walkin_end_hour
: String(rules.walkin_end_hour).padStart(2,"0")+":00";

document.getElementById("appointmentCutoffHour").value =
rules.today_appointment_cutoff_hour.includes(":")
? rules.today_appointment_cutoff_hour
: String(rules.today_appointment_cutoff_hour).padStart(2,"0")+":00";


document.getElementById(
"geoStart1"
).value =
rules.geo_start_1;

document.getElementById(
"geoStop1"
).value =
rules.geo_end_1;

document.getElementById(
"geoStart2"
).value =
rules.geo_start_2;

document.getElementById(
"geoStop2"
).value =
rules.geo_end_2;
document.getElementById(
"officeShortName"
).value =
rules.office_short_name;

document.getElementById("geofenceDistance").value =
    rules.geofence_distance_meters;
    document.getElementById("officeLatitude").value =
    rules.office_latitude;

document.getElementById("officeLongitude").value =
    rules.office_longitude;

document.getElementById("managerPreviousDays").value =
    rules.manager_previous_days;
    document.getElementById("officeDisplayEnglish").value =
rules.office_display_en || "";

document.getElementById("officeDisplayHindi").value =
rules.office_display_hi || "";

document.getElementById("managerFutureDays").value =
    rules.manager_future_days;


document.getElementById(
"watermarkText"
).value =
rules.watermark_text || "";

document.getElementById(
"gazetteOfficeAddress"
).value =
rules.gazette_office_address || "";


  renderDistricts(data.districts);
}

let dashboardFieldSettings = [];
let serviceFormFields=[];
let districtMaster=[];
let formFieldSettings = [];
let states=[];
let selectedState="";
const fieldLabels = {
    qrc: "QRC Number",
    name: "Name",
    mobile: "Mobile Number",
    aadhaar_last4: "Aadhaar Last 4 Digits",
    gender: "Gender",
    age: "Age",
    identity: "EID/SID Details",
    consent: "Declaration Consent"
};

const dashboardFieldLabels = {

    created_at: "Token Created",

    date: "Appointment / Walk-in Date",

    token_count: "Token Count",

    token_type: "Token Type",

    identity: "EID / SID",

    qrc: "QRC",

    name: "Name",

    mobile: "Mobile",

    aadhaar_last4: "Aadhaar Last 4",

    gender: "Gender",

    age: "Age",

    divyang: "PWD",
    state: "State",

    district: "District",

    service_type: "Service",

    expected_time: "Expected Time",

    entry_time: "Entry Time",

    visited_at: "Serviced At",

    time_taken: "Time Taken",

    reference_of: "Remarks",

    token: "Full Token",

    eid: "EID",

    sid: "SID",

    identity_type: "Identity Type",

    service_other: "Remarks"

};
const hiddenFields = [
    "district",
    "state",
    "consent"
];

async function loadDashboardFieldSettings(dashboard){

    const res =
        await fetch(
            `/gujarat/api/manager/dashboard-field-settings/${dashboard}`,
            {
                headers:{
                    "x-manager-token":managerToken
                }
            }
        );


    if(!res.ok){

        alert("Failed to load dashboard field settings");

        return;
    }


    dashboardFieldSettings =
        await res.json();


    const tbody =
        document.getElementById(
            "dashboardFieldTable"
        );


    tbody.innerHTML = "";


    dashboardFieldSettings.forEach(field => {

        const label =
            dashboardFieldLabels[field.field_key]
            ||
            field.field_key;


        tbody.innerHTML += `

        <tr>

            <td>
                ${label}
            </td>

            <td style="text-align:center">

                <input
                    type="checkbox"
                    class="dashboard-visible"
                    data-field="${field.field_key}"
                    ${field.visible === 1 ? "checked" : ""}
                >

            </td>

        </tr>

        `;

    });

}

async function saveDashboardFieldSettings(){

    const dashboard =
        document.getElementById(
            "dashboardFieldSelect"
        ).value;


    const rows =
        document.querySelectorAll(
            "#dashboardFieldTable tr"
        );


    const fields = [];


    rows.forEach(row => {

        const checkbox =
            row.querySelector(
                ".dashboard-visible"
            );


        fields.push({

            field_key:
                checkbox.dataset.field,

            visible:
                checkbox.checked ? 1 : 0

        });

    });


    const res =
        await fetch(
            "/gujarat/api/manager/dashboard-field-settings",
            {
                method:"POST",

                headers:{
                    "Content-Type":"application/json",
                    "x-manager-token":managerToken
                },

                body:JSON.stringify({

                    dashboard,

                    fields

                })

            }
        );


    const data =
        await res.json();


    if(!res.ok){

        alert(
            data.message ||
            "Failed to save dashboard field settings"
        );

        return;
    }


    alert(
        "Dashboard field visibility saved successfully"
    );

}


document
.getElementById("dashboardFieldSelect")
.addEventListener(
    "change",
    () => {

        loadDashboardFieldSettings(
            document.getElementById(
                "dashboardFieldSelect"
            ).value
        );

    }
);
async function loadServiceFormDropdown(){

const res =
await fetch("/gujarat/api/settings/service-types");


const services =
await res.json();


const select =
document.getElementById(
"serviceFormSelect"
);


select.innerHTML="";


services.forEach(s=>{


const option =
document.createElement("option");


option.value=s.id;

option.textContent=
s.english_name;


select.appendChild(option);


});


await loadServiceFormSettings(
select.value
);


select.onchange=()=>{

loadServiceFormSettings(
select.value
);

};


}
async function loadServiceFormSettings(id){


const res =
await fetch(
`/gujarat/api/settings/service-form-settings/${id}`
);


serviceFormFields =
await res.json();



const tbody =
document.getElementById(
"serviceFormTable"
);


tbody.innerHTML="";


serviceFormFields.filter(f => !hiddenFields.includes(f.field_key)).forEach(f=>{


tbody.innerHTML += `

<tr>

<td>
${fieldLabels[f.field_key] || f.field_key}
</td>


<td>

<input

type="checkbox"

class="enabled"

data-field="${f.field_key}"

${f.enabled ? "checked":""}

/>

</td>


<td>

<input

type="checkbox"

class="mandatory"

data-field="${f.field_key}"

${f.mandatory ? "checked":""}

/>

</td>


</tr>

`;

});


}
async function saveServiceFormSettings(){


const serviceId =
document.getElementById(
"serviceFormSelect"
).value;



const rows =
document.querySelectorAll(
"#serviceFormTable tr"
);



const fields=[];


rows.forEach(row=>{


const field =
row.querySelector(".enabled")
.dataset.field;



fields.push({

field_key:field,


enabled:
row.querySelector(".enabled").checked
?1:0,


mandatory:
row.querySelector(".mandatory").checked
?1:0

});


});



await fetch(
"/gujarat/api/manager/service-form-settings",
{

method:"POST",

headers:{
"Content-Type":"application/json"
},


body:JSON.stringify({

service_type_id:serviceId,

fields

})


});


alert(
"Saved successfully"
);


}


async function loadStates(){

const res = await fetch(
"/gujarat/api/settings/states"
);

states = await res.json();


const selects=[
"districtMasterState",
"priorityExistingStateSelect",
"geojsonState"
];


selects.forEach(id=>{

const select =
document.getElementById(id);

if(!select)
return;


select.innerHTML =
`
<option value="">
Select State
</option>
`;


states.forEach(s=>{

select.innerHTML +=
`
<option value="${s}">
${s}
</option>
`;

});


});


}
function loadDistrictDropdown() {
  const select = document.getElementById("districtSelect");
  select.innerHTML = "";

  districtMaster.forEach(d => {
    const option = document.createElement("option");

option.value = d.english_name;
option.textContent = 
d.english_name + 
" / " +
d.hindi_name;
    select.appendChild(option);
  });
}
async function loadUsers() {

    const res = await fetch(

        "/gujarat/api/manager/users",

        {

            headers: {

                "x-manager-token": managerToken

            }

        }

    );

    const users = await res.json();

    const container =
        document.getElementById(
            "usersContainer"
        );

    container.innerHTML = "";

    users.forEach(user => {


        container.innerHTML += `

<div class="user-card ${user.is_active==1 ? 'active-user':'disabled-user'}">

    <div class="user-row">

        <label>

            Role

        </label>

        <input
            value="${user.role}"
            readonly
        >

    </div>

    <div class="user-row">

        <label>

            Username

        </label>

        <input
            id="username-${user.id}"
            value="${user.username}"
        >

    </div>

    <div class="user-row">

        <label>

            New Password

        </label>

        <input
            type="password"
            id="password-${user.id}"
            placeholder="Leave blank to keep same password"
        >

    </div>
    <div class="user-row">

<label>
Status
</label>


<select id="status-${user.id}">

<option value="1"
${user.is_active==1?"selected":""}>
Active
</option>


<option value="0"
${user.is_active==0?"selected":""}>
Disabled
</option>


</select>

</div>

    <button
        onclick="saveUser(${user.id})">

        Save Changes

    </button>

</div>

`;

    });

}
async function loadWeekdaySlots(){


const res =
await fetch(
"/gujarat/api/manager/weekday-slots",
{
headers:{
"x-manager-token":managerToken
}
});


const data =
await res.json();


const tbody =
document.getElementById(
"weekdaySlots"
);


tbody.innerHTML="";


data.forEach(row=>{


tbody.innerHTML += `

<tr>

<td>
${row.weekday_name}
</td>


<td>

<input 
id="appt-${row.weekday}"
value="${row.appointment_total}"
>

</td>


<td>

<input
id="walk-${row.weekday}"
value="${row.walkin_total}"
>

</td>
<td>

<input
id="tph-${row.weekday}"
value="${row.tokens_per_hour || 30}"
type="number"
>

</td>
<td>
<input 
type="time"
id="start-${row.weekday}"
value="${row.work_start_time || ''}"
>
</td>

</tr>

`;

});


}

async function uploadGeojson(){

    const file =
        document.getElementById(
            "geojsonFile"
        ).files[0];


    const state =
        document.getElementById(
            "geojsonState"
        ).value;


    if(!state){

        alert(
            "Select state"
        );

        return;
    }


    if(!file){

        alert(
            "Select GeoJSON file"
        );

        return;
    }


    const formData =
        new FormData();


    formData.append(
        "geojson",
        file
    );


    formData.append(
        "state",
        state
    );


    const res =
    await fetch(
        "/gujarat/api/manager/upload-geojson",
        {
            method:"POST",

            headers:{
                "x-manager-token":managerToken
            },

            body:formData
        }
    );


    const data =
        await res.json();


    alert(data.message);

}

async function saveUser(id) {

    const username =
        document.getElementById(
            `username-${id}`
        ).value;

    const password =
        document.getElementById(
            `password-${id}`
        ).value;

    const res = await fetch(

        `/gujarat/api/manager/users/${id}`,

        {

            method: "POST",

            headers: {

                "Content-Type":
                    "application/json",

                "x-manager-token":
                    localStorage.getItem("managerToken")

            },

            body: JSON.stringify({

                username,

                password,
                is_active:
              Number(
              document.getElementById(
              `status-${id}`
              ).value
              )

            })

        }

    );

    const data =
        await res.json();

    if (!res.ok) {

        alert(data.message);

        return;

    }

    alert("User updated successfully");

    loadUsers();

}

async function deleteSelectedPriorityDistrict(){

    const district =
        document.getElementById(
            "priorityExistingDistrictSelect"
        ).value;


    const state =
        document.getElementById(
            "priorityExistingStateSelect"
        ).value;


    if(!state){
        alert("Select state");
        return;
    }


    if(!district){
        alert("Select district");
        return;
    }


    const res = await fetch(
        "/gujarat/api/manager/delete-priority-district",
        {
            method:"POST",

            headers:{
                "Content-Type":"application/json",
                "x-manager-token":managerToken
            },

            body:JSON.stringify({
                state,
                district
            })
        }
    );


    const data = await res.json();




    if(!res.ok){
        alert(data.message || "Delete failed");
        return;
    }


    alert("Priority district removed");


    loadSettings();

}
const priorityState =
document.getElementById(
"priorityExistingStateSelect"
);


if(priorityState){

priorityState.addEventListener(
"change",
function(){

loadDistrictsByState(
this.value,
"priorityDistrictSelect"
);

});

}
function renderDistricts(districts) {

const select =
document.getElementById(
"priorityExistingDistrictSelect"
);


if(!select)
return;


select.innerHTML="";


districts.forEach(d=>{

const option =
document.createElement("option");


option.value =
d.district;


option.textContent =
d.state+
" - "+
d.district;


select.appendChild(option);

});

}
async function loadNotices() {

  const res = await fetch("/gujarat/api/manager/notices", {
    headers: { "x-manager-token": managerToken }
  });

  const data = await res.json();

  const list = document.getElementById("noticeList");

  list.style.listStyle = "none";
  list.style.paddingLeft = "0";

  list.innerHTML = "";

  data.forEach(n => {

    const li = document.createElement("li");

    li.innerHTML = `
      <b>${n.date}</b> - ${n.message}
      <button class="removeBtn"
        style="margin-left:10px;padding:4px 10px;border:none;background:#d9534f;color:white;border-radius:4px;cursor:pointer;"
        onclick="deleteNotice('${n.date}')">
        Remove
      </button>
    `;

    li.style.display = "flex";
li.style.justifyContent = "space-between";
li.style.alignItems = "center";
li.style.margin = "12px 0";

    list.appendChild(li);
  });
}
async function saveNotice() {

  const date = document.getElementById("noticeDate").value;
  const message = document.getElementById("noticeText").value;

  if (!date || !message) {
    alert("Fill all fields");
    return;
  }

  await fetch("/gujarat/api/manager/save-notice", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-manager-token": managerToken
    },
    body: JSON.stringify({ date, message })
  });

  alert("Notice saved");
  loadNotices();
  document.getElementById("noticeDate").value = "";
  document.getElementById("noticeText").value = "";
}
async function deleteNotice(date) {

  await fetch("/gujarat/api/manager/delete-notice", {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      "x-manager-token": managerToken
    },
    body: JSON.stringify({ date })
  });

  loadNotices();
}
async function saveRules() {

  const child_age_limit = document.getElementById("childAge").value;
  const senior_age_limit = document.getElementById("seniorAge").value;
  const female_priority_age = document.getElementById("femaleAge").value;
const default_appointment_slots = null;
const default_walkin_slots = null;
const office_open_saturday = 0;
const office_open_sunday = 0;
    const appointment_days_visible =
    document.getElementById("appointmentDays").value;
    const walkin_start_hour =
    document.getElementById("walkinStartHour").value;

const walkin_end_hour =
    document.getElementById("walkinEndHour").value;

const today_appointment_cutoff_hour =
    document.getElementById("appointmentCutoffHour").value;


const geo_start_1 =
document.getElementById(
"geoStart1"
).value;

const geo_end_1 =
document.getElementById(
"geoStop1"
).value;

const geo_start_2 =
document.getElementById(
"geoStart2"
).value;

const geo_end_2 =
document.getElementById(
"geoStop2"
).value;

const geofence_distance_meters =
    Number(document.getElementById("geofenceDistance").value);
const office_latitude =
    Number(document.getElementById("officeLatitude").value);

const office_longitude =
    Number(document.getElementById("officeLongitude").value);

const manager_previous_days =
    Number(document.getElementById("managerPreviousDays").value);

const manager_future_days =
    Number(document.getElementById("managerFutureDays").value);


const default_tokens_per_hour = null;
const office_display_en =
document.getElementById(
"officeDisplayEnglish"
).value;
const office_short_name =
document.getElementById(
"officeShortName"
).value;


const office_display_hi =
document.getElementById(
"officeDisplayHindi"
).value;

const watermark_text = document.getElementById("watermarkText").value;
const gazette_office_address =
document.getElementById(
"gazetteOfficeAddress"
).value;


  await fetch("/gujarat/api/manager/update-priority-rules", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-manager-token": managerToken
    },
    body: JSON.stringify({
    child_age_limit,
    senior_age_limit,
    female_priority_age,
    default_appointment_slots,
    default_walkin_slots,

    appointment_days_visible,
    walkin_start_hour,
    walkin_end_hour,
    today_appointment_cutoff_hour,
    geo_start_1,
    geo_end_1,
    geo_start_2,
    geo_end_2,
    geofence_distance_meters,
    office_latitude,
    office_longitude,
    manager_previous_days,
    manager_future_days,
    office_open_saturday,
office_open_sunday,
    default_tokens_per_hour,
office_display_en,
office_display_hi,
office_short_name,
watermark_text,
gazette_office_address
})
  });

  alert("Rules updated");
}




async function uploadQR(type){


let input;


if(type==="dob")
input=document.getElementById("dobQR");


if(type==="name")
input=document.getElementById("nameQR");


if(type==="reactivation")
input=document.getElementById("reactivationQR");



const file =
input.files[0];


if(!file){

alert("Select QR first");

return;

}



const formData =
new FormData();


formData.append(
"qr",
file
);



const res =
await fetch(

"/gujarat/api/manager/upload-qr/"+type,

{

method:"POST",

body:formData

}

);



const data =
await res.json();



alert(data.message);



}
async function addDistrict() {

  const district =
    document.getElementById(
      "priorityDistrictSelect"
    ).value;


  const state =
    document.getElementById(
      "priorityExistingStateSelect"
    ).value;


  if(!state){
    alert("Select state");
    return;
  }


  if(!district){
    alert("Select district");
    return;
  }


  await fetch(
    "/gujarat/api/manager/add-priority-district",
    {
      method:"POST",

      headers:{
        "Content-Type":"application/json",
        "x-manager-token":managerToken
      },

      body:JSON.stringify({
        state,
        district
      })
    }
  );


  loadSettings();

}

async function deleteDistrict(district) {

  await fetch("/gujarat/api/manager/delete-priority-district", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-manager-token": managerToken
    },
    body: JSON.stringify({ state:
document.getElementById(
"priorityExistingStateSelect"
).value, district })
  });

  loadSettings();
}


async function loadHolidays() {

  const res = await fetch("/gujarat/api/manager/holidays", {
    headers: { "x-manager-token": managerToken }
  });

  const data = await res.json();

  const list = document.getElementById("holidayList");
  list.style.listStyle = "none";   
list.style.paddingLeft = "0";   
  list.innerHTML = "";

  data.forEach(h => {
    const li = document.createElement("li");

    li.innerHTML = `
      <b>${h.date}</b> - ${h.reason}
      <button class="removeBtn" style="margin-left:10px;padding:4px 10px;border:none;background:#d9534f;color:white;border-radius:4px;cursor:pointer;" onclick="deleteHoliday('${h.date}')">
  Remove
</button>
    `;
    li.style.display = "flex";
li.style.justifyContent = "space-between";
li.style.alignItems = "center";
li.style.margin = "12px 0";

    list.appendChild(li);
  });
}

async function addHoliday() {

  const date = document.getElementById("holidayDate").value;
  const reason = document.getElementById("holidayReason").value;

  if (!date) {
    alert("Select date");
    return;
  }

  await fetch("/gujarat/api/manager/add-holiday", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-manager-token": managerToken
    },
    body: JSON.stringify({ date, reason})
  });

  loadHolidays();
}
async function loadWorkingDays(){

    const res = await fetch(

        "/gujarat/api/manager/working-days",

        {

            headers:{

                "x-manager-token":managerToken

            }

        }

    );

    const rows = await res.json();

    const list =
        document.getElementById(
            "workingDayList"
        );

    list.innerHTML="";

    rows.forEach(r=>{

        list.innerHTML+=`

<li>

<b>${r.date}</b>

-

${r.reason}

<button
onclick="deleteWorkingDay('${r.date}')">

Remove

</button>

</li>

`;

    });

}

async function saveWeekdaySlots(){


const rows =
document.querySelectorAll(
"#weekdaySlots tr"
);


for(const row of rows){


const day =
row.querySelector("input")
.id.split("-")[1];


await fetch(
"/gujarat/api/manager/weekday-slots",
{

method:"POST",

headers:{
"Content-Type":"application/json",
"x-manager-token":managerToken
},


body:JSON.stringify({

weekday:Number(day),

appointment_total:
Number(
document.getElementById(
`appt-${day}`
).value
),


walkin_total:
Number(
document.getElementById(
`walk-${day}`
).value
),

tokens_per_hour:
Number(
document.getElementById(
`tph-${day}`
).value
),
 work_start_time:
 document.getElementById(
 `start-${day}`
 ).value

})


});


}


alert(
"Weekly slots updated"
);


}

async function addWorkingDay(){

    const date =
        document.getElementById(
            "workingDate"
        ).value;

    const reason =
        document.getElementById(
            "workingReason"
        ).value;

    await fetch(

        "/gujarat/api/manager/add-working-day",

        {

            method:"POST",

            headers:{

                "Content-Type":"application/json",

                "x-manager-token":managerToken

            },

            body:JSON.stringify({

                date,

                reason

            })

        }

    );

    loadWorkingDays();

}
async function deleteWorkingDay(date){

    await fetch(

        "/gujarat/api/manager/delete-working-day",

        {

            method:"DELETE",

            headers:{

                "Content-Type":"application/json",

                "x-manager-token":managerToken

            },

            body:JSON.stringify({

                date

            })

        }

    );

    loadWorkingDays();

}
async function loadServices(){

const res =
await fetch(
"/gujarat/api/settings/service-types"
);


const services =
await res.json();


const list =
document.getElementById(
"serviceList"
);


list.innerHTML="";


services.forEach(s=>{


list.innerHTML += `

<li>

${s.english_name}
/
${s.hindi_name}

<button onclick="deleteService(${s.id})">
Delete
</button>

</li>

`;

});


}

async function loadServiceTypes(){

const res =
await fetch(
"/gujarat/api/settings/service-types",
{
headers:{
"x-manager-token":managerToken
}
}
);

const data =
await res.json();


const select =
document.getElementById(
"serviceSelect"
);


select.innerHTML="";


data.forEach(s=>{

const option =
document.createElement("option");


option.value = s.id;


option.textContent =
s.english_name
+
" / "
+
s.hindi_name;


select.appendChild(option);

});


}
async function addServiceType(){

    const english_name =
        document.getElementById("serviceEnglish").value.trim();

    const hindi_name =
        document.getElementById("serviceHindi").value.trim();

    if(!english_name || !hindi_name){

        alert("Enter both English and Hindi service names.");

        return;
    }

    const res = await fetch(
        "/gujarat/api/manager/add-service-type",
        {
            method:"POST",

            headers:{
                "Content-Type":"application/json",
                "x-manager-token":managerToken
            },

            body:JSON.stringify({
                english_name,
                hindi_name
            })
        }
    );

    const data = await res.json();

    if(!res.ok){

        alert(data.message || "Failed to add service");

        return;
    }

    document.getElementById("serviceEnglish").value="";
    document.getElementById("serviceHindi").value="";

    await loadServiceTypes();
    await loadServiceFormDropdown();

    alert("Service added successfully.");
}


async function saveFormFieldSettings(){


    for(const field of formFieldSettings){


        const key = field.field_key;


        const enabled =
        document.querySelector(
            `.enable-${key}`
        ).checked;


        const mandatory =
        document.querySelector(
            `.mandatory-${key}`
        ).checked;



        const res = await fetch(
            `/gujarat/api/manager/form-field-settings/${key}`,
            {
                method:"POST",

                headers:{
                    "Content-Type":"application/json",
                    "x-manager-token":managerToken
                },

                body:JSON.stringify({

                    enabled: enabled ? 1 : 0,

                    mandatory: mandatory ? 1 : 0

                })
            }
        );


        if(!res.ok){

            const err =
            await res.json();



            alert(
                "Failed updating "+key
            );

            return;
        }

    }


    alert(
        "Form fields saved successfully"
    );


}



async function updateFormField(
fieldKey,
type,
value
){

const body={};


body[type] =
value ? 1 : 0;


const res =
await fetch(
`/gujarat/api/manager/form-field-settings/${fieldKey}`,
{
method:"POST",

headers:{
"Content-Type":"application/json",

"x-manager-token":
localStorage.getItem("managerToken")
},

body:
JSON.stringify(body)

});


const data =
await res.json();


if(!res.ok){

alert(
data.message ||
"Update failed"
);

}


}
async function loadDistrictsByState(state, targetId){

    const select =
    document.getElementById(targetId);


    select.innerHTML =
    `
    <option value="">
    Select District
    </option>
    `;


    if(!state)
        return;


    const res = await fetch(
        `/gujarat/api/settings/districts-by-state?state=${encodeURIComponent(state)}`,
        {
            headers:{
                "x-manager-token":managerToken
            }
        }
    );


    const districts =
    await res.json();



    districts.forEach(d=>{


        const option =
        document.createElement("option");


        option.value =
        d.english_name;


        option.textContent =
        d.english_name+
        " / "+
        d.hindi_name;


        select.appendChild(option);


    });

}

async function loadDistrictMaster(){

    const res = await fetch(
        "/gujarat/api/manager/district-master",
        {
            headers:{
                "x-manager-token":managerToken
            }
        }
    );


    const districts = await res.json();


    renderDistrictMaster(districts);


    
    districtMaster = districts;



}

async function deleteSelectedDistrictMaster(){

    const id =
    document.getElementById(
        "districtMasterSelect"
    ).value;


    if(!id){
        alert("Select district");
        return;
    }


    await fetch(
        "/gujarat/api/manager/delete-district-master/"+id,
        {
            method:"DELETE",
            headers:{
                "x-manager-token":managerToken
            }
        }
    );


    loadDistrictMaster();

}

function renderDistrictMaster(districts){

    const select =
        document.getElementById(
            "districtMasterSelect"
        );

    select.innerHTML="";


    districts.forEach(d=>{

        const option =
        document.createElement("option");

        option.value = d.id;

        option.textContent =
d.state+
" - "+
d.english_name+
" / "+
d.hindi_name;

        select.appendChild(option);

    });

}
async function addDistrictMaster(){


const english_name =
document.getElementById(
"districtMasterEnglish"
).value;


const hindi_name =
document.getElementById(
"districtMasterHindi"
).value;



if(
!english_name ||
!hindi_name
){

alert("Fill both names");

return;

}



await fetch(
"/gujarat/api/manager/add-district-master",
{

method:"POST",

headers:{
"Content-Type":"application/json",
"x-manager-token":managerToken
},

body:
JSON.stringify({
state:
document.getElementById(
"districtMasterState"
).value,
english_name,
hindi_name

})

});


document.getElementById(
"districtMasterEnglish"
).value="";


document.getElementById(
"districtMasterHindi"
).value="";


loadDistrictMaster();


}
async function deleteDistrictMaster(id){


await fetch(

"/gujarat/api/manager/delete-district-master/"+id,

{

method:"DELETE",

headers:{
"x-manager-token":managerToken
}

}

);


loadDistrictMaster();


}
async function deleteSelectedService(){

const id =
document.getElementById(
"serviceSelect"
).value;


if(!id){

alert("Select service");

return;

}


await fetch(
"/gujarat/api/manager/delete-service-type/"+id,
{
method:"DELETE",
headers:{
"x-manager-token":managerToken
}
}
);


loadServiceTypes();

}

async function deleteServiceType(id){


await fetch(
"/gujarat/api/manager/delete-service-type/"+id,
{

method:"DELETE",

headers:{
"x-manager-token":managerToken
}

});


loadServiceTypes();

}
async function deleteHoliday(date) {

  await fetch("/gujarat/api/manager/delete-holiday", {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      "x-manager-token": managerToken
    },
    body: JSON.stringify({ date })
  });

  loadHolidays();
}
loadDashboardFieldSettings("MANAGER");
loadStates();

loadSettings();
loadServiceFormDropdown();
loadDistrictMaster();
loadHolidays();
loadWorkingDays();
loadNotices();
loadUsers();
loadServiceTypes();
loadWeekdaySlots();



